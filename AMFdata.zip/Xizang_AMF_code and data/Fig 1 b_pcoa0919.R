rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(patchwork)
library(vegan)
library(scales)
library(ggtern)
library(labdsv) 
library(ggThemeAssist) 
library(plyr)
library(picante)
library(ggpubr)
library(ggtext)

######################################################################### pcoa root and soil PERMANOVA  betadisper
rs<-read.csv("root_soil.csv",header=T,row.names = 1) 
rs<-rs[,colSums(rs)>0]
gro<-read.csv("amfgroup.csv",header=T,row.names = 1) 
gro<-gro[gro$Compartment%in%c("Root","Soil"),]
compartment<-gro$Compartment
degradation<-gro$Degradation
ado<-adonis(rs~compartment*degradation,permutations=999,distance="bray")
ado$aov.tab

l_com<-rs[gro$Degradation=="Non",]
l_gro<-gro[gro$Degradation=="Non",]
l_ado<-adonis(l_com~l_gro$Compartment,permutations=999,distance="bray") 
l_ado$aov.tab 

m_com<-rs[gro$Degradation=="Moderately",]
m_gro<-gro[gro$Degradation=="Moderately",]
m_ado<-adonis(m_com~m_gro$Compartment,permutations=999,distance="bray") 
m_ado$aov.tab   

s_com<-rs[gro$Degradation=="Severely",]
s_gro<-gro[gro$Degradation=="Severely",]
s_ado<-adonis(s_com~s_gro$Compartment,permutations=999,distance="bray") 
s_ado$aov.tab  

community_hel <- decostand(rs, method = 'hellinger')
bc<-vegdist(community_hel,method="bray")

bc <- as.matrix(bc)
pcoa <- cmdscale(bc, eig=T)
eig <- summary(eigenvals(pcoa))
axis <- paste0("PCO", 1:ncol(eig))
eig <- data.frame(Axis = axis, t(eig)[, -3])
head(eig)
pco1 = round(eig[1, 3] * 100, 2)
pco2 = round(eig[2, 3] * 100, 2)
xlab = paste0("PCO1 (",pco1,"%)")
ylab = paste0("PCO2 (",pco2,"%)")
pcoa_points = as.data.frame(pcoa$points)
pcoa_points<-data.frame(row.names(pcoa_points),pcoa_points)
names(pcoa_points)[1]<-c("sample")
gro<-data.frame(row.names(gro),gro)
names(gro)[1]<-c("sample")
pcoa_points<-merge(pcoa_points, gro,by="sample")

pcoa_points$Degradation<-factor(pcoa_points$Degradation,levels = c("Non","Moderately","Severely"))
F_PCOA<-ggplot(pcoa_points,aes(x=V1,y=V2,color=Compartment,fill=Compartment,shape=Degradation))+
  geom_point(size=5,alpha=.6)+
  labs(x=xlab,y=ylab)+
  scale_shape_manual(values=c(15,17,16))+
  theme_bw()+
  annotate("text",x=0,y=-0.12,label="Compartment: R2 = 0.086 P = 0.003",size=3)+
  annotate("text",x=0,y=-0.14,label="Degradation: R2 = 0.090 P = 0.043",size=3)+
  annotate("text",x=0,y=-0.16,label="Compartment × Degradation: R2 = 0.104 P = 0.017",size=3)+
  theme(strip.text = element_text(size =12,face="bold"),
        legend.title = element_text(colour="black", size=10, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"))+
  scale_fill_manual(values =  c("red","blue"))+
  scale_color_manual(values =  c("red","blue"))
F_PCOA
