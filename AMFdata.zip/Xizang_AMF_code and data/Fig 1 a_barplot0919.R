rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(patchwork)
library(vegan)
library(scales)
library(ggtern)
library(labdsv) 
library(ggThemeAssist) 
library(plyr)
library(picante)
library(ggpubr)
library(ggtext)

#  otu table
amfotu<-read.csv("amfotu.csv", header=TRUE, row.names=1)
amfid<-read.csv("otuid.csv", header=TRUE)
amfgroup<-read.csv("amfgroup.csv", header=TRUE, row.names=1)
samplegroup<-read.csv("samplegroup.csv", header=TRUE)
S1 <- specnumber(amfotu)
(raremax1 <- min(rowSums(amfotu)))
Srare1 <- rarefy(amfotu, raremax1)
Srare1
#rarecurve(amfotu, step = 10, sample = raremax1, col = "blue", cex = 0.6)
#newOTU <- rrarefy(amfotu, raremax1)
#write.csv(newOTU,file='otuwork.csv')

otuwork<-read.csv("otuwork.csv", header=TRUE ,row.names=1)

root_soil<-otuwork[amfgroup$Compartment%in%c("Root","Soil"),]
root_soil_gro<-amfgroup[amfgroup$Compartment%in%c("Root","Soil"),]


###################################################################root soil  barplot
cb<-cbind(root_soil,root_soil_gro)
cb1<-aggregate(cb[1:115],by=list(treat=cb$treat),mean)
cb2<-colSums(cb1[2:116])
cb2<-data.frame(cb2)
cb2<-data.frame(row.names(cb2),cb2)
names(cb2)<-c("OTU", "otusum")
cb3<-t(cb1)
colnames(cb3)=cb3[1,]
cb3=cb3[-1,]
cb4<-cbind(cb3,cb2)
newdata<-merge(cb4,amfid,by="OTU")
newdata1<-newdata[order(-newdata$otusum),]
newdata1<-data.frame(newdata1[10],newdata1[2:7])
write.csv(newdata1,file = "newdata1.csv")
newdata1<-read.csv("newdata1.csv", header=TRUE ,row.names=1)
top10<-newdata1[c(1:10),]
others<-newdata1[c(11:nrow(newdata)),]
others<-colSums(others[2:7])
other2<-data.frame(others)
other3<-t(other2)
other3<-data.frame(row.names(other3),other3)
names(other3)[1]<-c("ID")
rs_rela<-rbind(top10,other3)
write.csv(rs_rela,file = "rs_rela-root_soil.csv")
rs_rela1<-melt(rs_rela)

names(rs_rela1)[2]<-c("treat")
rs_rela2<-merge(rs_rela1,samplegroup,by="treat")
rs_rela2$ID=factor(rs_rela2$ID,levels = c("OTU_1_Rhizophagus","OTU_2_Rhizophagus","OTU_3_Claroideoglomus",
                                          "OTU_7_Glomerales","OTU_170_Rhizophagus","OTU_8_Glomus",
                                          "OTU_26_Glomus","OTU_10_Glomus","OTU_132_Rhizophagus","OTU_4_Claroideoglomus","others"))


rs_rela2$Degradation<-factor(rs_rela2$Degradation,levels = c("Non","Moderately","Severely"))
col11<-c("#ff00ff","#00ff00", "deepskyblue", "blue", "red",
         "navy", "darkgreen","maroon3", "black", "bisque", "grey")
Fbar_rs<-ggplot(rs_rela2,aes(x=Compartment,y=value,fill=ID))+
  geom_bar(stat = "identity",position = 'fill')+
  scale_fill_manual(values= col11,name = "Taxon")+
  facet_grid(.~Degradation )+
  labs(x="",y = "Relative abundance")+
  theme_bw()+
  scale_y_continuous(labels=percent)+
  theme(strip.text = element_text(size =25,face="bold"),
        legend.title = element_text(colour="black", size=10, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=14,face="bold"))
Fbar_rs+ggtitle("a")