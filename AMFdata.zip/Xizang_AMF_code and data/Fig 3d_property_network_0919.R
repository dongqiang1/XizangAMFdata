rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

proall_network<-read.csv("proall_network.csv", header=TRUE,row.names = 1)
proall_network$Degradation<-factor(proall_network$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))


edges<-ggplot(data = proall_network, aes(x=Degradation,y=num.edges)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Number of edges")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(250,700))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
edges

vertices<-ggplot(data = proall_network, aes(x=Degradation,y=num.vertices)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Number of vertices")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(94,105))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
vertices

Connectance<-ggplot(data = proall_network, aes(x=Degradation,y=connectance)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Connectance")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(0.04,0.13))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
Connectance

Average_degree<-ggplot(data = proall_network, aes(x=Degradation,y=average.degree)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Average degree")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(5,13))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
Average_degree

Average_path_length<-ggplot(data = proall_network, aes(x=Degradation,y=average.path.length)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Average path length")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(2,4))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
Average_path_length

Average_clustering_coefficient<-ggplot(data = proall_network, aes(x=Degradation,y=clustering.coefficient)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Average clustering coefficient")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(0.33,0.68))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
Average_clustering_coefficient

property_network_4<- (edges|Connectance)/(Average_degree|Average_clustering_coefficient)
property_network_4






