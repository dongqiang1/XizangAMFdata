
rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

library(GO.db)
library(vegan)
library(permute)        
library(lattice)
library(WGCNA)
#library(multtest)
library(igraph)
library(brainGraph)
library(WGCNA)
library(psych)
library(reshape2)
library(igraph)
library(Hmisc)
library("GUniFrac")
library(sciplot)
library(ggpmisc)
#library(edgeR)
library(indicspecies)
library(BiocManager)
library(patchwork)
library(agricolae)
library(ggplot2)
library(ggraph)
library(colorRamps)
library(scales)

nd_order3<-read.csv("nd_order3.csv",header=T,row.names = 1) 
df1<-nd_order3
df_corr = corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
#cor_l<-as.matrix(df_corr$r)
#cor_l1<-data.frame(cor_l[upper.tri(cor_l)])
#cor_l2<-data.frame(rep("Non",nrow(cor_l1)),cor_l1)
#names(cor_l2)[1:2]<-c("degradation","cor")

df_corr_r = df_corr$r
df_corr_p = df_corr$p
df_corr_r[df_corr_p>0.05|abs(df_corr_r)<0.6] = 0
igraph <- graph_from_adjacency_matrix(df_corr_r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs = V(igraph )[degree(igraph) == 0]
igraph  = delete.vertices(igraph , bad.vs)
igraph 

a<-data.frame(as_edgelist(igraph, names=T) )
id= read.csv('otuid.csv', header=T)

names(a)[1:2]<-c("OTU_f","OTU_t")
names(id)[1:3]<-c("OTU_f","Genus_f","ID_f")
a1<-merge(a,id,by="OTU_f")

names(id)[1:3]<-c("OTU_t","Genus_t","ID_t")
a2<-merge(a1,id,by="OTU_t")

a3<-a2[,c(2,3,1,5)]
a3_order<-a3[order(a3$Genus_f),]
write.csv(a3_order,"a3_order.csv")

factor(a3$Genus_f)
factor(a3$Genus_t)

Acaulospora<-a3_order[a3_order$Genus_f%in%c("Acaulospora")|a3_order$Genus_t%in%c("Acaulospora"),]
Acaulospora<-Acaulospora[order(Acaulospora$Genus_t),]
Acaulospora$links<-ifelse(Acaulospora$Genus_f==Acaulospora$Genus_t,"intra_links","inter_links") 
Acaulospora$Genus<-c("Acaulospora")

Ambispora<-a3_order[a3_order$Genus_f%in%c("Ambispora")|a3_order$Genus_t%in%c("Ambispora"),]
Ambispora<-Ambispora[order(Ambispora$Genus_t),]
Ambispora$links<-ifelse(Ambispora$Genus_f==Ambispora$Genus_t,"intra_links","inter_links")
Ambispora$Genus<-c("Ambispora")

Archaeospora<-a3_order[a3_order$Genus_f%in%c("Archaeospora")|a3_order$Genus_t%in%c("Archaeospora"),]
Archaeospora<-Archaeospora[order(Archaeospora$Genus_t),]
Archaeospora$links<-ifelse(Archaeospora$Genus_f==Archaeospora$Genus_t,"intra_links","inter_links")
Archaeospora$Genus<-c("Archaeospora")

Claroideoglomus<-a3_order[a3_order$Genus_f%in%c("Claroideoglomus")|a3_order$Genus_t%in%c("Claroideoglomus"),]
Claroideoglomus<-Claroideoglomus[order(Claroideoglomus$Genus_t),]
Claroideoglomus$links<-ifelse(Claroideoglomus$Genus_f==Claroideoglomus$Genus_t,"intra_links","inter_links")
Claroideoglomus$Genus<-c("Claroideoglomus")

Diversispora<-a3_order[a3_order$Genus_f%in%c("Diversispora")|a3_order$Genus_t%in%c("Diversispora"),]
Diversispora<-Diversispora[order(Diversispora$Genus_t),]
Diversispora$links<-ifelse(Diversispora$Genus_f==Diversispora$Genus_t,"intra_links","inter_links")
Diversispora$Genus<-c("Diversispora")

Funneliformis<-a3_order[a3_order$Genus_f%in%c("Funneliformis")|a3_order$Genus_t%in%c("Funneliformis"),]
Funneliformis<-Funneliformis[order(Funneliformis$Genus_t),]
Funneliformis$links<-ifelse(Funneliformis$Genus_f==Funneliformis$Genus_t,"intra_links","inter_links")
Funneliformis$Genus<-c("Funneliformis")

Glomerales<-a3_order[a3_order$Genus_f%in%c("Glomerales")|a3_order$Genus_t%in%c("Glomerales"),]
Glomerales<-Glomerales[order(Glomerales$Genus_t),]
Glomerales$links<-ifelse(Glomerales$Genus_f==Glomerales$Genus_t,"intra_links","inter_links")
Glomerales$Genus<-c("Glomerales")

Glomus<-a3_order[a3_order$Genus_f%in%c("Glomus")|a3_order$Genus_t%in%c("Glomus"),]
Glomus<-Glomus[order(Glomus$Genus_t),]
Glomus$links<-ifelse(Glomus$Genus_f==Glomus$Genus_t,"intra_links","inter_links")
Glomus$Genus<-c("Glomus")

Rhizophagus<-a3_order[a3_order$Genus_f%in%c("Rhizophagus")|a3_order$Genus_t%in%c("Rhizophagus"),]
Rhizophagus<-Rhizophagus[order(Rhizophagus$Genus_t),]
Rhizophagus$links<-ifelse(Rhizophagus$Genus_f==Rhizophagus$Genus_t,"intra_links","inter_links")
Rhizophagus$Genus<-c("Rhizophagus")

Paraglomus<-a3_order[a3_order$Genus_f%in%c("Paraglomus")|a3_order$Genus_t%in%c("Paraglomus"),]
Paraglomus<-Paraglomus[order(Paraglomus$Genus_t),]
Paraglomus$links<-ifelse(Paraglomus$Genus_f==Paraglomus$Genus_t,"intra_links","inter_links")
Paraglomus$Genus<-c("Paraglomus")

Scutellospora<-a3_order[a3_order$Genus_f%in%c("Scutellospora")|a3_order$Genus_t%in%c("Scutellospora"),]
Scutellospora<-Scutellospora[order(Scutellospora$Genus_t),]
Scutellospora$links<-ifelse(Scutellospora$Genus_f==Scutellospora$Genus_t,"intra_links","inter_links")
Scutellospora$Genus<-c("Scutellospora")

Septoglomus<-a3_order[a3_order$Genus_f%in%c("Septoglomus")|a3_order$Genus_t%in%c("Septoglomus"),]
Septoglomus<-Septoglomus[order(Septoglomus$Genus_t),]
Septoglomus$links<-ifelse(Septoglomus$Genus_f==Septoglomus$Genus_t,"intra_links","inter_links")
Septoglomus$Genus<-c("Septoglomus")

intra_inter<-rbind(Acaulospora[,c(5:6)],Ambispora[,c(5:6)],Archaeospora[,c(5:6)],Claroideoglomus[,c(5:6)],Diversispora[,c(5:6)],
                   Funneliformis[,c(5:6)],Glomerales[,c(5:6)],Glomus[,c(5:6)],Rhizophagus[,c(5:6)],Paraglomus[,c(5:6)],Scutellospora[,c(5:6)],Septoglomus[,c(5:6)])

intra_inter$links_number<-1

intra_inter_sum<-data.frame(aggregate(intra_inter$links_number,by=list(intra_inter$Genus,intra_inter$links),sum))
names(intra_inter_sum)[1:3]<-c("Genus","Links","Links_number")
intra_inter_sum<-intra_inter_sum[order(intra_inter_sum$Genus),]
write.csv(intra_inter_sum,"intra_inter_sum_nd.csv")

intra_inter_sum$Links<-factor(intra_inter_sum$Links,levels = c("intra_links","inter_links"))
p_number_nd<-ggplot(intra_inter_sum,aes(x=Genus,y=Links_number,fill=Links)) +
  geom_bar(stat="identity",position = position_dodge(0.9),width = 0.7)+
  theme_bw()+
  xlab(" ")+
  ylab("The number of network links") +
  theme(strip.text = element_text(size = 15,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=15, face="bold"),
        legend.text = element_text(colour="black", size=15, face="bold"),
        axis.text=element_text(size=12,face="bold"),
        axis.text.x=element_text(size=13,face="bold",color="black",angle = 45,hjust = 1),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=15,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+
  scale_fill_manual(values =  c("blue","red"))
p_number_nd


df1<-nd_order3
df_corr = corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
df_corr_r = df_corr$r
Cor<-as.matrix(df_corr_r )
Cor.df<-data.frame(row=rownames(Cor)[row(Cor)[upper.tri(Cor)]], 
                   col=colnames(Cor)[col(Cor)[upper.tri(Cor)]], Cor=Cor[upper.tri(Cor)])

id= read.csv('otuid.csv', header=T)

names(Cor.df)[1:2]<-c("OTU_f","OTU_t")
names(id)[1:3]<-c("OTU_f","Genus_f","ID_f")
a1<-merge(Cor.df,id,by="OTU_f")

names(id)[1:3]<-c("OTU_t","Genus_t","ID_t")
a2<-merge(a1,id,by="OTU_t")
a2<-a2[a2$Cor>0,]

a3<-a2[,c(2,4,1,6)]
a3_order<-a3[order(a3$Genus_f),]
107*108/2

Acaulospora<-a3_order[a3_order$Genus_f%in%c("Acaulospora")|a3_order$Genus_t%in%c("Acaulospora"),]
Acaulospora<-Acaulospora[order(Acaulospora$Genus_t),]
Acaulospora$links<-ifelse(Acaulospora$Genus_f==Acaulospora$Genus_t,"intra_links","inter_links") 
Acaulospora$Genus<-c("Acaulospora")

Ambispora<-a3_order[a3_order$Genus_f%in%c("Ambispora")|a3_order$Genus_t%in%c("Ambispora"),]
Ambispora<-Ambispora[order(Ambispora$Genus_t),]
Ambispora$links<-ifelse(Ambispora$Genus_f==Ambispora$Genus_t,"intra_links","inter_links")
Ambispora$Genus<-c("Ambispora")

Archaeospora<-a3_order[a3_order$Genus_f%in%c("Archaeospora")|a3_order$Genus_t%in%c("Archaeospora"),]
Archaeospora<-Archaeospora[order(Archaeospora$Genus_t),]
Archaeospora$links<-ifelse(Archaeospora$Genus_f==Archaeospora$Genus_t,"intra_links","inter_links")
Archaeospora$Genus<-c("Archaeospora")

Claroideoglomus<-a3_order[a3_order$Genus_f%in%c("Claroideoglomus")|a3_order$Genus_t%in%c("Claroideoglomus"),]
Claroideoglomus<-Claroideoglomus[order(Claroideoglomus$Genus_t),]
Claroideoglomus$links<-ifelse(Claroideoglomus$Genus_f==Claroideoglomus$Genus_t,"intra_links","inter_links")
Claroideoglomus$Genus<-c("Claroideoglomus")

Diversispora<-a3_order[a3_order$Genus_f%in%c("Diversispora")|a3_order$Genus_t%in%c("Diversispora"),]
Diversispora<-Diversispora[order(Diversispora$Genus_t),]
Diversispora$links<-ifelse(Diversispora$Genus_f==Diversispora$Genus_t,"intra_links","inter_links")
Diversispora$Genus<-c("Diversispora")

Funneliformis<-a3_order[a3_order$Genus_f%in%c("Funneliformis")|a3_order$Genus_t%in%c("Funneliformis"),]
Funneliformis<-Funneliformis[order(Funneliformis$Genus_t),]
Funneliformis$links<-ifelse(Funneliformis$Genus_f==Funneliformis$Genus_t,"intra_links","inter_links")
Funneliformis$Genus<-c("Funneliformis")

Glomerales<-a3_order[a3_order$Genus_f%in%c("Glomerales")|a3_order$Genus_t%in%c("Glomerales"),]
Glomerales<-Glomerales[order(Glomerales$Genus_t),]
Glomerales$links<-ifelse(Glomerales$Genus_f==Glomerales$Genus_t,"intra_links","inter_links")
Glomerales$Genus<-c("Glomerales")

Glomus<-a3_order[a3_order$Genus_f%in%c("Glomus")|a3_order$Genus_t%in%c("Glomus"),]
Glomus<-Glomus[order(Glomus$Genus_t),]
Glomus$links<-ifelse(Glomus$Genus_f==Glomus$Genus_t,"intra_links","inter_links")
Glomus$Genus<-c("Glomus")

Rhizophagus<-a3_order[a3_order$Genus_f%in%c("Rhizophagus")|a3_order$Genus_t%in%c("Rhizophagus"),]
Rhizophagus<-Rhizophagus[order(Rhizophagus$Genus_t),]
Rhizophagus$links<-ifelse(Rhizophagus$Genus_f==Rhizophagus$Genus_t,"intra_links","inter_links")
Rhizophagus$Genus<-c("Rhizophagus")

Paraglomus<-a3_order[a3_order$Genus_f%in%c("Paraglomus")|a3_order$Genus_t%in%c("Paraglomus"),]
Paraglomus<-Paraglomus[order(Paraglomus$Genus_t),]
Paraglomus$links<-ifelse(Paraglomus$Genus_f==Paraglomus$Genus_t,"intra_links","inter_links")
Paraglomus$Genus<-c("Paraglomus")

Scutellospora<-a3_order[a3_order$Genus_f%in%c("Scutellospora")|a3_order$Genus_t%in%c("Scutellospora"),]
Scutellospora<-Scutellospora[order(Scutellospora$Genus_t),]
Scutellospora$links<-ifelse(Scutellospora$Genus_f==Scutellospora$Genus_t,"intra_links","inter_links")
Scutellospora$Genus<-c("Scutellospora")

Septoglomus<-a3_order[a3_order$Genus_f%in%c("Septoglomus")|a3_order$Genus_t%in%c("Septoglomus"),]
Septoglomus<-Septoglomus[order(Septoglomus$Genus_t),]
Septoglomus$links<-ifelse(Septoglomus$Genus_f==Septoglomus$Genus_t,"intra_links","inter_links")
Septoglomus$Genus<-c("Septoglomus")

all_intra_inter<-rbind(Acaulospora[,c(5:6)],Ambispora[,c(5:6)],Archaeospora[,c(5:6)],Claroideoglomus[,c(5:6)],Diversispora[,c(5:6)],
                       Funneliformis[,c(5:6)],Glomerales[,c(5:6)],Glomus[,c(5:6)],Rhizophagus[,c(5:6)],Paraglomus[,c(5:6)],Scutellospora[,c(5:6)],Septoglomus[,c(5:6)])

all_intra_inter$links_number<-1

all_intra_inter_sum<-data.frame(aggregate(all_intra_inter$links_number,by=list(all_intra_inter$Genus,all_intra_inter$links),sum))
names(all_intra_inter_sum)[1:3]<-c("Genus","Links","all_Links_number")
all_intra_inter_sum<-all_intra_inter_sum[order(all_intra_inter_sum$Genus),]

all_intra_inter_sum$Genus_Links<-sprintf("%s_%s", all_intra_inter_sum$Genus, all_intra_inter_sum$Links)
all_intra_inter_sum
write.csv(all_intra_inter_sum,"all_intra_inter_sum_nd.csv")


intra_inter_sum
intra_inter_sum$Genus_Links<-sprintf("%s_%s", intra_inter_sum$Genus,intra_inter_sum$Links)
intra_inter_sum

#links<-cbind(all_intra_inter_sum,intra_inter_sum)

nd_links<-read.csv("links_nd.csv",header=T,row.names = 1)
nd_links$degradation<-c("Non_Degraded")
nd_links$Links<-factor(nd_links$Links,levels = c("intra_links","inter_links"))

df_2<-data.frame(row.names(nd_order3),nd_order3)
names(df_2)[1]<-c("OTU")
id= read.csv('otuid.csv', header=T)
df_3<-merge(df_2,id,by="OTU")
df_3$number<-1
OTU_sum<-data.frame(aggregate(df_3$number,by=list(df_3$Genus),sum))
OTU_sum

############################################################################## moderately 

#rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

md_order3<-read.csv("md_order3.csv",header=T,row.names = 1)

df1<-md_order3
df_corr = corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
#cor_l<-as.matrix(df_corr$r)
#cor_l1<-data.frame(cor_l[upper.tri(cor_l)])
#cor_l2<-data.frame(rep("Non",nrow(cor_l1)),cor_l1)
#names(cor_l2)[1:2]<-c("degradation","cor")

df_corr_r = df_corr$r
df_corr_p = df_corr$p
df_corr_r[df_corr_p>0.05|abs(df_corr_r)<0.6] = 0
igraph <- graph_from_adjacency_matrix(df_corr_r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs = V(igraph )[degree(igraph) == 0]
igraph  = delete.vertices(igraph , bad.vs)
igraph 

igraph.weight<-data.frame(E(igraph)$weight)


a<-data.frame(as_edgelist(igraph, names=T) )
aa<-cbind(a,igraph.weight)
a_negative<-aa[aa$E.igraph..weight<0,]

id= read.csv('otuid.csv', header=T)
#########################################################  negative
names(a_negative)[1:2]<-c("OTU_f","OTU_t")
names(id)[1:3]<-c("OTU_f","Genus_f","ID_f")
aa1<-merge(a_negative,id,by="OTU_f")

names(id)[1:3]<-c("OTU_t","Genus_t","ID_t")
aa2<-merge(aa1,id,by="OTU_t")
aa3<-aa2[,c(2,4,1,6)]
aa3_order<-aa3[order(aa3$Genus_f),]
######################################################################### positive

a<-data.frame(as_edgelist(igraph, names=T) )
a<-aa[aa$E.igraph..weight>0,]
a<-a[,c(1,2)]

names(a)[1:2]<-c("OTU_f","OTU_t")
names(id)[1:3]<-c("OTU_f","Genus_f","ID_f")
a1<-merge(a,id,by="OTU_f")

names(id)[1:3]<-c("OTU_t","Genus_t","ID_t")
a2<-merge(a1,id,by="OTU_t")

a3<-a2[,c(2,3,1,5)]
a3_order<-a3[order(a3$Genus_f),]
write.csv(a3_order,"a3_order.csv")

factor(a3$Genus_f)
factor(a3$Genus_t)

Acaulospora<-a3_order[a3_order$Genus_f%in%c("Acaulospora")|a3_order$Genus_t%in%c("Acaulospora"),]
Acaulospora<-Acaulospora[order(Acaulospora$Genus_t),]
Acaulospora$links<-ifelse(Acaulospora$Genus_f==Acaulospora$Genus_t,"intra_links","inter_links") 
Acaulospora$Genus<-c("Acaulospora")

Ambispora<-a3_order[a3_order$Genus_f%in%c("Ambispora")|a3_order$Genus_t%in%c("Ambispora"),]
Ambispora<-Ambispora[order(Ambispora$Genus_t),]
Ambispora$links<-ifelse(Ambispora$Genus_f==Ambispora$Genus_t,"intra_links","inter_links")
Ambispora$Genus<-c("Ambispora")

Archaeospora<-a3_order[a3_order$Genus_f%in%c("Archaeospora")|a3_order$Genus_t%in%c("Archaeospora"),]
Archaeospora<-Archaeospora[order(Archaeospora$Genus_t),]
Archaeospora$links<-ifelse(Archaeospora$Genus_f==Archaeospora$Genus_t,"intra_links","inter_links")
#Archaeospora$Genus<-c("Archaeospora")

Claroideoglomus<-a3_order[a3_order$Genus_f%in%c("Claroideoglomus")|a3_order$Genus_t%in%c("Claroideoglomus"),]
Claroideoglomus<-Claroideoglomus[order(Claroideoglomus$Genus_t),]
Claroideoglomus$links<-ifelse(Claroideoglomus$Genus_f==Claroideoglomus$Genus_t,"intra_links","inter_links")
Claroideoglomus$Genus<-c("Claroideoglomus")

Diversispora<-a3_order[a3_order$Genus_f%in%c("Diversispora")|a3_order$Genus_t%in%c("Diversispora"),]
Diversispora<-Diversispora[order(Diversispora$Genus_t),]
Diversispora$links<-ifelse(Diversispora$Genus_f==Diversispora$Genus_t,"intra_links","inter_links")
Diversispora$Genus<-c("Diversispora")

Funneliformis<-a3_order[a3_order$Genus_f%in%c("Funneliformis")|a3_order$Genus_t%in%c("Funneliformis"),]
Funneliformis<-Funneliformis[order(Funneliformis$Genus_t),]
Funneliformis$links<-ifelse(Funneliformis$Genus_f==Funneliformis$Genus_t,"intra_links","inter_links")
Funneliformis$Genus<-c("Funneliformis")

Glomerales<-a3_order[a3_order$Genus_f%in%c("Glomerales")|a3_order$Genus_t%in%c("Glomerales"),]
Glomerales<-Glomerales[order(Glomerales$Genus_t),]
Glomerales$links<-ifelse(Glomerales$Genus_f==Glomerales$Genus_t,"intra_links","inter_links")
Glomerales$Genus<-c("Glomerales")

Glomus<-a3_order[a3_order$Genus_f%in%c("Glomus")|a3_order$Genus_t%in%c("Glomus"),]
Glomus<-Glomus[order(Glomus$Genus_t),]
Glomus$links<-ifelse(Glomus$Genus_f==Glomus$Genus_t,"intra_links","inter_links")
Glomus$Genus<-c("Glomus")

Rhizophagus<-a3_order[a3_order$Genus_f%in%c("Rhizophagus")|a3_order$Genus_t%in%c("Rhizophagus"),]
Rhizophagus<-Rhizophagus[order(Rhizophagus$Genus_t),]
Rhizophagus$links<-ifelse(Rhizophagus$Genus_f==Rhizophagus$Genus_t,"intra_links","inter_links")
Rhizophagus$Genus<-c("Rhizophagus")

Paraglomus<-a3_order[a3_order$Genus_f%in%c("Paraglomus")|a3_order$Genus_t%in%c("Paraglomus"),]
Paraglomus<-Paraglomus[order(Paraglomus$Genus_t),]
Paraglomus$links<-ifelse(Paraglomus$Genus_f==Paraglomus$Genus_t,"intra_links","inter_links")
#Paraglomus$Genus<-c("Paraglomus")

Scutellospora<-a3_order[a3_order$Genus_f%in%c("Scutellospora")|a3_order$Genus_t%in%c("Scutellospora"),]
Scutellospora<-Scutellospora[order(Scutellospora$Genus_t),]
Scutellospora$links<-ifelse(Scutellospora$Genus_f==Scutellospora$Genus_t,"intra_links","inter_links")
Scutellospora$Genus<-c("Scutellospora")

Septoglomus<-a3_order[a3_order$Genus_f%in%c("Septoglomus")|a3_order$Genus_t%in%c("Septoglomus"),]
Septoglomus<-Septoglomus[order(Septoglomus$Genus_t),]
Septoglomus$links<-ifelse(Septoglomus$Genus_f==Septoglomus$Genus_t,"intra_links","inter_links")
#Septoglomus$Genus<-c("Septoglomus")

intra_inter<-rbind(Acaulospora[,c(5:6)],Ambispora[,c(5:6)],Claroideoglomus[,c(5:6)],Diversispora[,c(5:6)],
                   Funneliformis[,c(5:6)],Glomerales[,c(5:6)],Glomus[,c(5:6)],Rhizophagus[,c(5:6)],Scutellospora[,c(5:6)])

intra_inter$links_number<-1

intra_inter_sum<-data.frame(aggregate(intra_inter$links_number,by=list(intra_inter$Genus,intra_inter$links),sum))
names(intra_inter_sum)[1:3]<-c("Genus","Links","Links_number")
intra_inter_sum<-intra_inter_sum[order(intra_inter_sum$Genus),]
write.csv(intra_inter_sum,"intra_inter_sum_md.csv")

intra_inter_sum$Links<-factor(intra_inter_sum$Links,levels = c("intra_links","inter_links"))
p_number_md<-ggplot(intra_inter_sum,aes(x=Genus,y=Links_number,fill=Links)) +
  geom_bar(stat="identity",position = position_dodge(0.9),width = 0.7)+
  theme_bw()+
  xlab(" ")+
  ylab("The number of network links") +
  theme(strip.text = element_text(size = 15,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=15, face="bold"),
        legend.text = element_text(colour="black", size=15, face="bold"),
        axis.text=element_text(size=12,face="bold"),
        axis.text.x=element_text(size=13,face="bold",color="black",angle = 45,hjust = 1),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=15,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+
  scale_fill_manual(values =  c("blue","red"))
p_number_md


df1<-md_order3
df_corr = corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
df_corr_r = df_corr$r
Cor<-as.matrix(df_corr_r )
Cor.df<-data.frame(row=rownames(Cor)[row(Cor)[upper.tri(Cor)]], 
                   col=colnames(Cor)[col(Cor)[upper.tri(Cor)]], Cor=Cor[upper.tri(Cor)])

id= read.csv('otuid.csv', header=T)

names(Cor.df)[1:2]<-c("OTU_f","OTU_t")
names(id)[1:3]<-c("OTU_f","Genus_f","ID_f")
a1<-merge(Cor.df,id,by="OTU_f")

names(id)[1:3]<-c("OTU_t","Genus_t","ID_t")
a2<-merge(a1,id,by="OTU_t")
a2<-a2[a2$Cor>0,]

a3<-a2[,c(2,4,1,6)]
a3_order<-a3[order(a3$Genus_f),]
107*108/2

Acaulospora<-a3_order[a3_order$Genus_f%in%c("Acaulospora")|a3_order$Genus_t%in%c("Acaulospora"),]
Acaulospora<-Acaulospora[order(Acaulospora$Genus_t),]
Acaulospora$links<-ifelse(Acaulospora$Genus_f==Acaulospora$Genus_t,"intra_links","inter_links") 
Acaulospora$Genus<-c("Acaulospora")

Ambispora<-a3_order[a3_order$Genus_f%in%c("Ambispora")|a3_order$Genus_t%in%c("Ambispora"),]
Ambispora<-Ambispora[order(Ambispora$Genus_t),]
Ambispora$links<-ifelse(Ambispora$Genus_f==Ambispora$Genus_t,"intra_links","inter_links")
Ambispora$Genus<-c("Ambispora")

Archaeospora<-a3_order[a3_order$Genus_f%in%c("Archaeospora")|a3_order$Genus_t%in%c("Archaeospora"),]
Archaeospora<-Archaeospora[order(Archaeospora$Genus_t),]
Archaeospora$links<-ifelse(Archaeospora$Genus_f==Archaeospora$Genus_t,"intra_links","inter_links")
#Archaeospora$Genus<-c("Archaeospora")

Claroideoglomus<-a3_order[a3_order$Genus_f%in%c("Claroideoglomus")|a3_order$Genus_t%in%c("Claroideoglomus"),]
Claroideoglomus<-Claroideoglomus[order(Claroideoglomus$Genus_t),]
Claroideoglomus$links<-ifelse(Claroideoglomus$Genus_f==Claroideoglomus$Genus_t,"intra_links","inter_links")
Claroideoglomus$Genus<-c("Claroideoglomus")

Diversispora<-a3_order[a3_order$Genus_f%in%c("Diversispora")|a3_order$Genus_t%in%c("Diversispora"),]
Diversispora<-Diversispora[order(Diversispora$Genus_t),]
Diversispora$links<-ifelse(Diversispora$Genus_f==Diversispora$Genus_t,"intra_links","inter_links")
Diversispora$Genus<-c("Diversispora")

Funneliformis<-a3_order[a3_order$Genus_f%in%c("Funneliformis")|a3_order$Genus_t%in%c("Funneliformis"),]
Funneliformis<-Funneliformis[order(Funneliformis$Genus_t),]
Funneliformis$links<-ifelse(Funneliformis$Genus_f==Funneliformis$Genus_t,"intra_links","inter_links")
Funneliformis$Genus<-c("Funneliformis")

Glomerales<-a3_order[a3_order$Genus_f%in%c("Glomerales")|a3_order$Genus_t%in%c("Glomerales"),]
Glomerales<-Glomerales[order(Glomerales$Genus_t),]
Glomerales$links<-ifelse(Glomerales$Genus_f==Glomerales$Genus_t,"intra_links","inter_links")
Glomerales$Genus<-c("Glomerales")

Glomus<-a3_order[a3_order$Genus_f%in%c("Glomus")|a3_order$Genus_t%in%c("Glomus"),]
Glomus<-Glomus[order(Glomus$Genus_t),]
Glomus$links<-ifelse(Glomus$Genus_f==Glomus$Genus_t,"intra_links","inter_links")
Glomus$Genus<-c("Glomus")

Rhizophagus<-a3_order[a3_order$Genus_f%in%c("Rhizophagus")|a3_order$Genus_t%in%c("Rhizophagus"),]
Rhizophagus<-Rhizophagus[order(Rhizophagus$Genus_t),]
Rhizophagus$links<-ifelse(Rhizophagus$Genus_f==Rhizophagus$Genus_t,"intra_links","inter_links")
Rhizophagus$Genus<-c("Rhizophagus")

Paraglomus<-a3_order[a3_order$Genus_f%in%c("Paraglomus")|a3_order$Genus_t%in%c("Paraglomus"),]
Paraglomus<-Paraglomus[order(Paraglomus$Genus_t),]
Paraglomus$links<-ifelse(Paraglomus$Genus_f==Paraglomus$Genus_t,"intra_links","inter_links")
#Paraglomus$Genus<-c("Paraglomus")

Scutellospora<-a3_order[a3_order$Genus_f%in%c("Scutellospora")|a3_order$Genus_t%in%c("Scutellospora"),]
Scutellospora<-Scutellospora[order(Scutellospora$Genus_t),]
Scutellospora$links<-ifelse(Scutellospora$Genus_f==Scutellospora$Genus_t,"intra_links","inter_links")
Scutellospora$Genus<-c("Scutellospora")

Septoglomus<-a3_order[a3_order$Genus_f%in%c("Septoglomus")|a3_order$Genus_t%in%c("Septoglomus"),]
Septoglomus<-Septoglomus[order(Septoglomus$Genus_t),]
Septoglomus$links<-ifelse(Septoglomus$Genus_f==Septoglomus$Genus_t,"intra_links","inter_links")
Septoglomus$Genus<-c("Septoglomus")

all_intra_inter<-rbind(Acaulospora[,c(5:6)],Ambispora[,c(5:6)],Claroideoglomus[,c(5:6)],Diversispora[,c(5:6)],
                       Funneliformis[,c(5:6)],Glomerales[,c(5:6)],Glomus[,c(5:6)],Rhizophagus[,c(5:6)],Scutellospora[,c(5:6)],Septoglomus[,c(5:6)])

all_intra_inter$links_number<-1

all_intra_inter_sum<-data.frame(aggregate(all_intra_inter$links_number,by=list(all_intra_inter$Genus,all_intra_inter$links),sum))
names(all_intra_inter_sum)[1:3]<-c("Genus","Links","all_Links_number")
all_intra_inter_sum<-all_intra_inter_sum[order(all_intra_inter_sum$Genus),]

all_intra_inter_sum$Genus_Links<-sprintf("%s_%s", all_intra_inter_sum$Genus, all_intra_inter_sum$Links)
all_intra_inter_sum
write.csv(all_intra_inter_sum,"all_intra_inter_sum_md.csv")

intra_inter_sum
intra_inter_sum$Genus_Links<-sprintf("%s_%s", intra_inter_sum$Genus,intra_inter_sum$Links)
intra_inter_sum

#links<-cbind(all_intra_inter_sum,intra_inter_sum)
md_links<-read.csv("links_md.csv",header = T, row.names = 1)
md_links$degradation<-c("Moderately_Degraded")

md_links$Links<-factor(md_links$Links,levels = c("intra_links","inter_links"))

df_2<-data.frame(row.names(md_order3),md_order3)
names(df_2)[1]<-c("OTU")
id= read.csv('otuid.csv', header=T)
df_3<-merge(df_2,id,by="OTU")
df_3$number<-1
OTU_sum<-data.frame(aggregate(df_3$number,by=list(df_3$Genus),sum))
OTU_sum


###################################################################   severely 
#rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

sd_order3<-read.csv("sd_order3.csv",header=T,row.names = 1)

df1<-sd_order3
df_corr = corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
#cor_l<-as.matrix(df_corr$r)
#cor_l1<-data.frame(cor_l[upper.tri(cor_l)])
#cor_l2<-data.frame(rep("Non",nrow(cor_l1)),cor_l1)
#names(cor_l2)[1:2]<-c("degradation","cor")

df_corr_r = df_corr$r
df_corr_p = df_corr$p
df_corr_r[df_corr_p>0.05|abs(df_corr_r)<0.6] = 0
igraph <- graph_from_adjacency_matrix(df_corr_r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs = V(igraph )[degree(igraph) == 0]
igraph  = delete.vertices(igraph , bad.vs)
igraph 

igraph.weight<-data.frame(E(igraph)$weight)


a<-data.frame(as_edgelist(igraph, names=T) )
aa<-cbind(a,igraph.weight)
a_negative<-aa[aa$E.igraph..weight<0,]

id= read.csv('otuid.csv', header=T)
#########################################################  negative
names(a_negative)[1:2]<-c("OTU_f","OTU_t")
names(id)[1:3]<-c("OTU_f","Genus_f","ID_f")
aa1<-merge(a_negative,id,by="OTU_f")

names(id)[1:3]<-c("OTU_t","Genus_t","ID_t")
aa2<-merge(aa1,id,by="OTU_t")
aa3<-aa2[,c(2,4,1,6)]
aa3_order<-aa3[order(aa3$Genus_f),]
######################################################################### positive

a<-data.frame(as_edgelist(igraph, names=T) )
a<-aa[aa$E.igraph..weight>0,]
a<-a[,c(1,2)]

names(a)[1:2]<-c("OTU_f","OTU_t")
names(id)[1:3]<-c("OTU_f","Genus_f","ID_f")
a1<-merge(a,id,by="OTU_f")

names(id)[1:3]<-c("OTU_t","Genus_t","ID_t")
a2<-merge(a1,id,by="OTU_t")

a3<-a2[,c(2,3,1,5)]
a3_order<-a3[order(a3$Genus_f),]
write.csv(a3_order,"a3_order.csv")

factor(a3$Genus_f)
factor(a3$Genus_t)

Acaulospora<-a3_order[a3_order$Genus_f%in%c("Acaulospora")|a3_order$Genus_t%in%c("Acaulospora"),]
Acaulospora<-Acaulospora[order(Acaulospora$Genus_t),]
Acaulospora$links<-ifelse(Acaulospora$Genus_f==Acaulospora$Genus_t,"intra_links","inter_links") 
Acaulospora$Genus<-c("Acaulospora")

Ambispora<-a3_order[a3_order$Genus_f%in%c("Ambispora")|a3_order$Genus_t%in%c("Ambispora"),]
Ambispora<-Ambispora[order(Ambispora$Genus_t),]
Ambispora$links<-ifelse(Ambispora$Genus_f==Ambispora$Genus_t,"intra_links","inter_links")
#Ambispora$Genus<-c("Ambispora")

Archaeospora<-a3_order[a3_order$Genus_f%in%c("Archaeospora")|a3_order$Genus_t%in%c("Archaeospora"),]
Archaeospora<-Archaeospora[order(Archaeospora$Genus_t),]
Archaeospora$links<-ifelse(Archaeospora$Genus_f==Archaeospora$Genus_t,"intra_links","inter_links")
Archaeospora$Genus<-c("Archaeospora")

Claroideoglomus<-a3_order[a3_order$Genus_f%in%c("Claroideoglomus")|a3_order$Genus_t%in%c("Claroideoglomus"),]
Claroideoglomus<-Claroideoglomus[order(Claroideoglomus$Genus_t),]
Claroideoglomus$links<-ifelse(Claroideoglomus$Genus_f==Claroideoglomus$Genus_t,"intra_links","inter_links")
Claroideoglomus$Genus<-c("Claroideoglomus")

Diversispora<-a3_order[a3_order$Genus_f%in%c("Diversispora")|a3_order$Genus_t%in%c("Diversispora"),]
Diversispora<-Diversispora[order(Diversispora$Genus_t),]
Diversispora$links<-ifelse(Diversispora$Genus_f==Diversispora$Genus_t,"intra_links","inter_links")
Diversispora$Genus<-c("Diversispora")

Funneliformis<-a3_order[a3_order$Genus_f%in%c("Funneliformis")|a3_order$Genus_t%in%c("Funneliformis"),]
Funneliformis<-Funneliformis[order(Funneliformis$Genus_t),]
Funneliformis$links<-ifelse(Funneliformis$Genus_f==Funneliformis$Genus_t,"intra_links","inter_links")
Funneliformis$Genus<-c("Funneliformis")

Glomerales<-a3_order[a3_order$Genus_f%in%c("Glomerales")|a3_order$Genus_t%in%c("Glomerales"),]
Glomerales<-Glomerales[order(Glomerales$Genus_t),]
Glomerales$links<-ifelse(Glomerales$Genus_f==Glomerales$Genus_t,"intra_links","inter_links")
Glomerales$Genus<-c("Glomerales")

Glomus<-a3_order[a3_order$Genus_f%in%c("Glomus")|a3_order$Genus_t%in%c("Glomus"),]
Glomus<-Glomus[order(Glomus$Genus_t),]
Glomus$links<-ifelse(Glomus$Genus_f==Glomus$Genus_t,"intra_links","inter_links")
Glomus$Genus<-c("Glomus")

Rhizophagus<-a3_order[a3_order$Genus_f%in%c("Rhizophagus")|a3_order$Genus_t%in%c("Rhizophagus"),]
Rhizophagus<-Rhizophagus[order(Rhizophagus$Genus_t),]
Rhizophagus$links<-ifelse(Rhizophagus$Genus_f==Rhizophagus$Genus_t,"intra_links","inter_links")
Rhizophagus$Genus<-c("Rhizophagus")

Paraglomus<-a3_order[a3_order$Genus_f%in%c("Paraglomus")|a3_order$Genus_t%in%c("Paraglomus"),]
Paraglomus<-Paraglomus[order(Paraglomus$Genus_t),]
Paraglomus$links<-ifelse(Paraglomus$Genus_f==Paraglomus$Genus_t,"intra_links","inter_links")
Paraglomus$Genus<-c("Paraglomus")

Scutellospora<-a3_order[a3_order$Genus_f%in%c("Scutellospora")|a3_order$Genus_t%in%c("Scutellospora"),]
Scutellospora<-Scutellospora[order(Scutellospora$Genus_t),]
Scutellospora$links<-ifelse(Scutellospora$Genus_f==Scutellospora$Genus_t,"intra_links","inter_links")
Scutellospora$Genus<-c("Scutellospora")

Septoglomus<-a3_order[a3_order$Genus_f%in%c("Septoglomus")|a3_order$Genus_t%in%c("Septoglomus"),]
Septoglomus<-Septoglomus[order(Septoglomus$Genus_t),]
Septoglomus$links<-ifelse(Septoglomus$Genus_f==Septoglomus$Genus_t,"intra_links","inter_links")
Septoglomus$Genus<-c("Septoglomus")

intra_inter<-rbind(Acaulospora[,c(5:6)],Archaeospora[,c(5:6)],Claroideoglomus[,c(5:6)],Diversispora[,c(5:6)],
                   Funneliformis[,c(5:6)],Glomerales[,c(5:6)],Glomus[,c(5:6)],Rhizophagus[,c(5:6)],Paraglomus[,c(5:6)],Scutellospora[,c(5:6)],Septoglomus[,c(5:6)])

intra_inter$links_number<-1

intra_inter_sum<-data.frame(aggregate(intra_inter$links_number,by=list(intra_inter$Genus,intra_inter$links),sum))
names(intra_inter_sum)[1:3]<-c("Genus","Links","Links_number")
intra_inter_sum<-intra_inter_sum[order(intra_inter_sum$Genus),]
write.csv(intra_inter_sum,"intra_inter_sum_sd.csv")

intra_inter_sum$Links<-factor(intra_inter_sum$Links,levels = c("intra_links","inter_links"))
p_number_sd<-ggplot(intra_inter_sum,aes(x=Genus,y=Links_number,fill=Links)) +
  geom_bar(stat="identity",position = position_dodge(0.9),width = 0.7)+
  theme_bw()+
  xlab(" ")+
  ylab("The number of network links") +
  theme(strip.text = element_text(size = 15,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=15, face="bold"),
        legend.text = element_text(colour="black", size=15, face="bold"),
        axis.text=element_text(size=12,face="bold"),
        axis.text.x=element_text(size=13,face="bold",color="black",angle = 45,hjust = 1),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=15,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+
  scale_fill_manual(values =  c("blue","red"))
p_number_sd


df1<-sd_order3
df_corr = corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
df_corr_r = df_corr$r
Cor<-as.matrix(df_corr_r )
Cor.df<-data.frame(row=rownames(Cor)[row(Cor)[upper.tri(Cor)]], 
                   col=colnames(Cor)[col(Cor)[upper.tri(Cor)]], Cor=Cor[upper.tri(Cor)])

id= read.csv('otuid.csv', header=T)

names(Cor.df)[1:2]<-c("OTU_f","OTU_t")
names(id)[1:3]<-c("OTU_f","Genus_f","ID_f")
a1<-merge(Cor.df,id,by="OTU_f")

names(id)[1:3]<-c("OTU_t","Genus_t","ID_t")
a2<-merge(a1,id,by="OTU_t")
a2<-a2[a2$Cor>0,]

a3<-a2[,c(2,4,1,6)]
a3_order<-a3[order(a3$Genus_f),]
107*108/2

Acaulospora<-a3_order[a3_order$Genus_f%in%c("Acaulospora")|a3_order$Genus_t%in%c("Acaulospora"),]
Acaulospora<-Acaulospora[order(Acaulospora$Genus_t),]
Acaulospora$links<-ifelse(Acaulospora$Genus_f==Acaulospora$Genus_t,"intra_links","inter_links") 
Acaulospora$Genus<-c("Acaulospora")

Ambispora<-a3_order[a3_order$Genus_f%in%c("Ambispora")|a3_order$Genus_t%in%c("Ambispora"),]
Ambispora<-Ambispora[order(Ambispora$Genus_t),]
Ambispora$links<-ifelse(Ambispora$Genus_f==Ambispora$Genus_t,"intra_links","inter_links")
#Ambispora$Genus<-c("Ambispora")

Archaeospora<-a3_order[a3_order$Genus_f%in%c("Archaeospora")|a3_order$Genus_t%in%c("Archaeospora"),]
Archaeospora<-Archaeospora[order(Archaeospora$Genus_t),]
Archaeospora$links<-ifelse(Archaeospora$Genus_f==Archaeospora$Genus_t,"intra_links","inter_links")
Archaeospora$Genus<-c("Archaeospora")

Claroideoglomus<-a3_order[a3_order$Genus_f%in%c("Claroideoglomus")|a3_order$Genus_t%in%c("Claroideoglomus"),]
Claroideoglomus<-Claroideoglomus[order(Claroideoglomus$Genus_t),]
Claroideoglomus$links<-ifelse(Claroideoglomus$Genus_f==Claroideoglomus$Genus_t,"intra_links","inter_links")
Claroideoglomus$Genus<-c("Claroideoglomus")

Diversispora<-a3_order[a3_order$Genus_f%in%c("Diversispora")|a3_order$Genus_t%in%c("Diversispora"),]
Diversispora<-Diversispora[order(Diversispora$Genus_t),]
Diversispora$links<-ifelse(Diversispora$Genus_f==Diversispora$Genus_t,"intra_links","inter_links")
Diversispora$Genus<-c("Diversispora")

Funneliformis<-a3_order[a3_order$Genus_f%in%c("Funneliformis")|a3_order$Genus_t%in%c("Funneliformis"),]
Funneliformis<-Funneliformis[order(Funneliformis$Genus_t),]
Funneliformis$links<-ifelse(Funneliformis$Genus_f==Funneliformis$Genus_t,"intra_links","inter_links")
Funneliformis$Genus<-c("Funneliformis")

Glomerales<-a3_order[a3_order$Genus_f%in%c("Glomerales")|a3_order$Genus_t%in%c("Glomerales"),]
Glomerales<-Glomerales[order(Glomerales$Genus_t),]
Glomerales$links<-ifelse(Glomerales$Genus_f==Glomerales$Genus_t,"intra_links","inter_links")
Glomerales$Genus<-c("Glomerales")

Glomus<-a3_order[a3_order$Genus_f%in%c("Glomus")|a3_order$Genus_t%in%c("Glomus"),]
Glomus<-Glomus[order(Glomus$Genus_t),]
Glomus$links<-ifelse(Glomus$Genus_f==Glomus$Genus_t,"intra_links","inter_links")
Glomus$Genus<-c("Glomus")

Rhizophagus<-a3_order[a3_order$Genus_f%in%c("Rhizophagus")|a3_order$Genus_t%in%c("Rhizophagus"),]
Rhizophagus<-Rhizophagus[order(Rhizophagus$Genus_t),]
Rhizophagus$links<-ifelse(Rhizophagus$Genus_f==Rhizophagus$Genus_t,"intra_links","inter_links")
Rhizophagus$Genus<-c("Rhizophagus")

Paraglomus<-a3_order[a3_order$Genus_f%in%c("Paraglomus")|a3_order$Genus_t%in%c("Paraglomus"),]
Paraglomus<-Paraglomus[order(Paraglomus$Genus_t),]
Paraglomus$links<-ifelse(Paraglomus$Genus_f==Paraglomus$Genus_t,"intra_links","inter_links")
Paraglomus$Genus<-c("Paraglomus")

Scutellospora<-a3_order[a3_order$Genus_f%in%c("Scutellospora")|a3_order$Genus_t%in%c("Scutellospora"),]
Scutellospora<-Scutellospora[order(Scutellospora$Genus_t),]
Scutellospora$links<-ifelse(Scutellospora$Genus_f==Scutellospora$Genus_t,"intra_links","inter_links")
Scutellospora$Genus<-c("Scutellospora")

Septoglomus<-a3_order[a3_order$Genus_f%in%c("Septoglomus")|a3_order$Genus_t%in%c("Septoglomus"),]
Septoglomus<-Septoglomus[order(Septoglomus$Genus_t),]
Septoglomus$links<-ifelse(Septoglomus$Genus_f==Septoglomus$Genus_t,"intra_links","inter_links")
Septoglomus$Genus<-c("Septoglomus")

all_intra_inter<-rbind(Acaulospora[,c(5:6)],Archaeospora[,c(5:6)],Claroideoglomus[,c(5:6)],Diversispora[,c(5:6)],
                       Funneliformis[,c(5:6)],Glomerales[,c(5:6)],Glomus[,c(5:6)],Rhizophagus[,c(5:6)],Paraglomus[,c(5:6)],Scutellospora[,c(5:6)],Septoglomus[,c(5:6)])

all_intra_inter$links_number<-1

all_intra_inter_sum<-data.frame(aggregate(all_intra_inter$links_number,by=list(all_intra_inter$Genus,all_intra_inter$links),sum))
names(all_intra_inter_sum)[1:3]<-c("Genus","Links","all_Links_number")
all_intra_inter_sum<-all_intra_inter_sum[order(all_intra_inter_sum$Genus),]

all_intra_inter_sum$Genus_Links<-sprintf("%s_%s", all_intra_inter_sum$Genus, all_intra_inter_sum$Links)
write.csv(all_intra_inter_sum,"all_intra_inter_sum_sd.csv")

intra_inter_sum
intra_inter_sum$Genus_Links<-sprintf("%s_%s", intra_inter_sum$Genus,intra_inter_sum$Links)
intra_inter_sum

#links<-cbind(all_intra_inter_sum,intra_inter_sum)
sd_links<-read.csv("links_sd.csv",header = T, row.names = 1)
sd_links$degradation<-c("Severely_Degraded")
sd_links$Links<-factor(sd_links$Links,levels = c("intra_links","inter_links"))

df_2<-data.frame(row.names(sd_order3),sd_order3)
names(df_2)[1]<-c("OTU")
id= read.csv('otuid.csv', header=T)
df_3<-merge(df_2,id,by="OTU")
df_3$number<-1
OTU_sum<-data.frame(aggregate(df_3$number,by=list(df_3$Genus),sum))
OTU_sum

##########################################################
all_links<-rbind(nd_links,md_links,sd_links)

all_links$Linkages<-all_links$Links
all_links$Linkages_1<-ifelse(all_links$Linkages=="intra_links","Within genus links","Links between one particular genus and other genera") 

all_links$degradation<-factor(all_links$degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
all_links$Linkages_1<-factor(all_links$Linkages_1,levels = c("Within genus links","Links between one particular genus and other genera"))

p_positive<-ggplot(all_links,aes(x=all_Links_number,y=Links_number,shape=Linkages_1,color=Genus))+
  geom_point(size=6)+
  theme_bw()+
  facet_grid(Linkages_1~degradation)+
  xlab("The number of theoretical positive-linkages ")+
  ylab("The number of actual positive-linkages")+
  scale_color_manual(values = c("green","#FF3300","#9999FF","darkgreen","cyan","#CCFFCC","grey","#0000FF","#FF3399","red","black","navy"), 
                     limits = c("Acaulospora","Ambispora","Archaeospora","Claroideoglomus","Diversispora",
                                "Funneliformis","Glomerales","Glomus","Paraglomus","Rhizophagus","Scutellospora","Septoglomus"))+
  theme(strip.text = element_text(size = 18,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=15, face="bold"),
        legend.text = element_text(colour="black", size=13, face="bold"),
        axis.text=element_text(size=12,face="bold"),
        axis.text.x=element_text(size=13,face="bold",color="black",hjust = 1),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=15,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))
p_positive


