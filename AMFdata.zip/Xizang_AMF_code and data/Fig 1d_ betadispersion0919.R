rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(patchwork)
library(vegan)
library(scales)
library(ggtern)
library(labdsv) 
library(ggThemeAssist) 
library(plyr)
library(picante)
library(ggpubr)
library(ggtext)

#################################################Bray–Curtis dissimilarity between root and soil arbuscular mycorrhizal fungal community
rs<-read.csv("root_soil.csv",header=T,row.names = 1) 
rs<-rs[,colSums(rs)>0]
gro<-read.csv("amfgroup.csv",header=T,row.names = 1) 
gro<-gro[gro$Compartment%in%c("Root","Soil"),]
compartment<-gro$Compartment
degradation<-gro$Degradation
ado<-adonis(rs~compartment*degradation,permutations=999,distance="bray")
ado$aov.tab

l_com<-rs[gro$Degradation=="Non",]
l_gro<-gro[gro$Degradation=="Non",]
l_ado<-adonis(l_com~l_gro$Compartment,permutations=999,distance="bray") 
l_ado$aov.tab 

m_com<-rs[gro$Degradation=="Moderately",]
m_gro<-gro[gro$Degradation=="Moderately",]
m_ado<-adonis(m_com~m_gro$Compartment,permutations=999,distance="bray") 
m_ado$aov.tab   

s_com<-rs[gro$Degradation=="Severely",]
s_gro<-gro[gro$Degradation=="Severely",]
s_ado<-adonis(s_com~s_gro$Compartment,permutations=999,distance="bray") 
s_ado$aov.tab  


community_hel <- decostand(rs, method = 'hellinger')
bc<-vegdist(community_hel,method="bray")
bd<-betadisper(bc,factor(gro$treat))
print (anova(bd))
boxplot(bd)
fs2<-data.frame(bd$distances,gro$treat,gro$Degradation,gro$Compartment)
str(fs2)
shapiro.test(fs2$bd.distances)
bartlett.test(bd.distances~gro.treat,data = fs2)
dis_kw<-kruskal.test(bd.distances~gro.treat,data = fs2)
dis_kw
kw <- kruskal(fs2$bd.distances, fs2$gro.treat, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('ab','d','bc','cd','a','cd')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("treat")
gro<-read.csv("samplegroup.csv",header=T)
gro<-gro[gro$Compartment%in%c("Root","Soil"),]
kwsig<-merge(kwsig,gro,by="treat")

twoway_aov<-aov(bd.distances ~ gro.Degradation*gro.Compartment,data = fs2)
summary(twoway_aov)

kwsig$Degradation<-factor(kwsig$Degradation,levels = c("Non","Moderately","Severely"))
F_betadispersion_1<-ggplot(kwsig,aes(x=Degradation,y=fs2.bd.distances,fill=Compartment))+
  geom_errorbar(aes(ymin = fs2.bd.distances-0.05, ymax = fs2.bd.distances + std), width = 0.2, size = 0.1, position = position_dodge(0.9)) +
  geom_bar(stat='identity',width = 0.8,position = position_dodge(0.9))+
  geom_text(aes(y=fs2.bd.distances+std+0.02,label=kwsig),color="black",position = position_dodge(0.9),size=6)+
  theme_bw()+
  annotate("text",x=2,y=0.35,label="F = 6.71 ***",size=5)+
  labs(x="",y = "Beta dispersion")+
  theme(strip.text = element_text(size =12,face="bold"),
        legend.title = element_text(colour="black", size=10, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text.y=element_text(size=10,face="bold"),
        axis.text.x=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=11,face="bold"))+
  labs(color="Comparment")+
  scale_fill_manual(values =  c("red","blue"))
F_betadispersion_1

fs2$gro.Degradation<-factor(fs2$gro.Degradation,levels = c("Non","Moderately","Severely"))
F_betadispersion<-ggplot(fs2,aes(x=gro.Degradation,y=bd.distances,color=gro.Compartment))+
  stat_boxplot(geom ="errorbar", width = .2, size=.7,position = position_dodge(0.9))+
  geom_boxplot(position = position_dodge(0.9))+
  theme_bw()+
  annotate("text",x=0.75,y=0.1,label="bc",size=5,color="black")+
  annotate("text",x=1.23,y=0.1,label="cd",size=5,color="black")+
  annotate("text",x=1.75,y=0.3,label="ab",size=5,color="black")+
  annotate("text",x=2.23,y=0.1,label="d",size=5,color="black")+
  annotate("text",x=2.77,y=0.4,label="a",size=5,color="black")+
  annotate("text",x=3.23,y=0.1,label="cd",size=5,color="black")+
  annotate("text",x=2.05,y=0.45,label=expression(~chi^2==21.396~~P==0.001),size=6,color="red",face="bold")+
  labs(x=" ",y = "Bray–Curtis dissimilarity of<br>AM fungalcommunity")+
  theme(strip.text = element_text(size =12,face="bold"),
        legend.title = element_text(colour="black", size=10, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=15,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"),
        axis.title.y = element_markdown(size=12,face="bold"))+
  labs(color="Compartment")+
  scale_color_manual(values =  c("red","blue"))+
  scale_y_continuous(limits = c(0,0.45))
#+
#  stat_compare_means(aes(group =gro.Compartment),method = "t.test",size=3)

F_betadispersion



(Fbar_rs|F_PCOA)/(F_dissimilarity|F_betadispersion)+ plot_annotation(tag_levels = "a")&
  theme(plot.tag = element_text(size=20,face="bold"))


