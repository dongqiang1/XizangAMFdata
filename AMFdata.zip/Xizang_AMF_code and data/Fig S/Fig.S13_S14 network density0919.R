rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")
library(GO.db)
library(vegan)
library(permute)        
library(lattice)
library(WGCNA)
#library(multtest)
library(igraph)
library(brainGraph)
library(WGCNA)
library(psych)
library(reshape2)
library(igraph)
library(Hmisc)
library("GUniFrac")
library(sciplot)
library(ggpmisc)
#library(edgeR)
library(indicspecies)
library(BiocManager)
library(patchwork)
library(agricolae)
library(ggplot2)
library(ggraph)
library(colorRamps)

#######################################################################network correlations density
nd_order3<-read.csv("nd_order3.csv",header=T,row.names = 1) 
md_order3<-read.csv("md_order3.csv",header=T,row.names = 1) 
sd_order3<-read.csv("sd_order3.csv",header=T,row.names = 1) 

df1<-nd_order3
df_corr<-corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
cor_n<-as.matrix(df_corr$r)
cor_n1<-data.frame(cor_n[upper.tri(cor_n)])
cor_n2<-data.frame(rep("Non_Degraded",nrow(cor_n1)),cor_n1)
names(cor_n2)[1:2]<-c("Degradation","cor")
n<- ggplot(data = cor_n2, aes(x=cor)) +
  geom_density(size=0.5,colour="blue") 
n

df1<-md_order3
df_corr<-corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
cor_m<-as.matrix(df_corr$r)
cor_m1<-data.frame(cor_m[upper.tri(cor_m)])
cor_m2<-data.frame(rep("Moderately_Degraded",nrow(cor_m1)),cor_m1)
names(cor_m2)[1:2]<-c("Degradation","cor")
m <- ggplot(data = cor_m2, aes(x=cor)) +
  geom_density(size=0.5,colour="blue") 
m

df1<-sd_order3
df_corr<-corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
cor_s<-as.matrix(df_corr$r)
cor_s1<-data.frame(cor_s[upper.tri(cor_s)])
cor_s2<-data.frame(rep("Severely_Degraded",nrow(cor_s1)),cor_s1)
names(cor_s2)[1:2]<-c("Degradation","cor")
s<- ggplot(data = cor_s2, aes(x=cor)) +
  geom_density(size=0.5,colour="blue") 
s

cor_density<-rbind(cor_n2,cor_m2,cor_s2)
mean1 <- aggregate(cor~Degradation, FUN = "mean", data = cor_density)
mean1

cor_density$Degradation<-factor(cor_density$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
all_density<- ggplot(data = cor_density, aes(x=cor,linetype=Degradation,color=Degradation)) +
  geom_density(size=1) +
  geom_vline(data=mean1, aes(xintercept=cor,linetype=Degradation,color=Degradation), size=0.5) +
  scale_linetype_manual(name ="Degradation",values = c(1,1,1)) +
  scale_color_manual(name="Degradation",values = c("#00FF7F","#006400","blue"))+
  theme_bw() +
  labs(x="Spearman's Rho", y="Density")+
  theme(
    axis.text.x=element_text(size=7,face="bold",color="black"),
    axis.text.y=element_text(size=7,face="bold",color="black"),
    axis.title = element_text(size =15, face = "bold"),
    axis.text = element_text(size = 8),
    legend.title = element_text(colour = "black", size = 13, face = "bold"),
    legend.text = element_text(colour = "black", size = 13, face = "bold"))

all_density

#all, positive ad negative correlations 
all<-data.frame(rep("All Spearman's Rho",nrow(cor_density)),cor_density)
names(all)[1]<-c("network")
positive<-data.frame(cor_density[cor_density$cor>0,])
positive1<-data.frame(rep("Postive Spearman's Rho",nrow(positive)),positive)
names(positive1)[1]<-c("network")

negative<-data.frame(cor_density[cor_density$cor<0,])
negative1<-data.frame(rep("Negative Spearman's Rho",nrow(negative)),negative$Degradation,negative$cor)
names(negative1)[1:3]<-c("network","Degradation","cor")

all_lm<-rbind(all,positive1,negative1)

all_lm$network<-factor(all_lm$network,levels = c("All Spearman's Rho","Postive Spearman's Rho","Negative Spearman's Rho"))
all_cor<-ggplot(data = all_lm, aes(x=as.numeric(Degradation),y=cor,color = network,linetype=network)) + 
  geom_smooth(method='lm', size =1, se = FALSE)+
  scale_color_manual(values = c("black", "red","blue"))+
  scale_linetype_manual(values = c(1, 1, 1))+
  xlab("")+ylab("Spearman's Rho")+theme_bw()+
  scale_x_continuous(breaks = c(1,2,3),labels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))+
  theme(strip.text = element_text(size = 10,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=10, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text.x=element_text(colour="black",size=10,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=10,face="bold"))
all_cor


all_cor1<-ggplot(data = cor_density, aes(x=as.numeric(Degradation),y=cor,color="black")) + 
  geom_smooth(method='lm', size =1, se = FALSE)+
  scale_color_manual(values = c("black"))+
  xlab("")+ylab("All Spearman's Rho")+theme_bw()+
  scale_x_continuous(breaks = c(1,2,3),labels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))+
  theme(strip.text = element_text(size = 10,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=10, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text.x=element_text(colour="black",size=10,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=10,face="bold"))+theme(legend.position="none")
all_cor1


bartlett.test(cor_density$cor~Degradation,data = cor_density)
all_kw<-kruskal.test(cor_density$cor~Degradation,data = cor_density)
all_kw
kw <- kruskal(cor_density$cor, cor_density$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('b','b','a')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")
all_cor_j_2<-ggplot(data = cor_density, aes(x=as.numeric(Degradation),y=cor,color="black")) + 
  geom_smooth(method='lm', size =3, se = FALSE)+
  scale_color_manual(values = c("black"))+
  geom_jitter(size = 0.1, alpha = 0.1)+
  ggtitle(expression(~chi^2==10.033~~P==0.007))+
  xlab("")+ylab("All Spearman's Rho")+theme_bw()+
  annotate("text",x=1,y=1.1,label="b",size=5,color="black")+
  annotate("text",x=2,y=1.1,label="b",size=5,color="black")+
  annotate("text",x=3,y=1.1,label="a",size=5,color="black")+
  scale_x_continuous(breaks = c(1,2,3),labels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))+
  scale_y_continuous(limits = c(-1,1.4))+
  theme(strip.text = element_text(size = 10,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=10, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text.x=element_text(colour="black",size=10,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=10,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+theme(legend.position="none")
all_cor_j_2

library(gghalves)

means<-data.frame(row.names(kw$means),kw$means)
names(means)[1:2]<-c("Degradation","means")
means$Degradation<-factor(means$Degradation,levels = c("Non_degraded","Moderately_degraded","Severely_degraded"))


library(gghalves)
all_cor_j_3<-ggplot(data = cor_density,
                    aes(x=Degradation, y=cor,colo=Degradation, fill=Degradation)) +
  geom_half_violin(side = "r", color=NA, alpha=0.4) +
  geom_half_boxplot(side = "r", errorbar.draw = FALSE, width=0.2, linewidth=0.5) +
  geom_half_point_panel(side = "l", shape=21, size=0.4,range_scale=2,alpha=0.7,color="white")+
  theme_bw()+
  xlab(" ")+
  ylab("All Spearman's Rho")+
  ggtitle(expression(~chi^2==10.033~~P==0.007))+
  annotate("text",x=1,y=1.1,label="b",size=5,color="black")+
  annotate("text",x=2,y=1.1,label="b",size=5,color="black")+
  annotate("text",x=3,y=1.1,label="a",size=5,color="black")+
  
  annotate("point", x = 1, y =0.1142308,colour = "red", size = 1)+ 
  annotate("point", x = 2, y =0.1100891,colour = "red", size = 1)+ 
  annotate("point", x = 3, y =0.1368889,colour = "red", size = 1)+ 
  
  annotate("segment", x = 1, y =0.1142308,xend  = 2, yend =0.1100891,colour = "red", size = 1)+ 
  annotate("segment", x = 2, y =0.1100891,xend = 3, yend =0.1368889,colour = "red", size = 1)+ 
  
  scale_fill_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_text(size=12,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+
  scale_y_continuous(limits = c(-1,1.5))
all_cor_j_3


bartlett.test(positive1$cor~Degradation,data = positive1)
all_kw<-kruskal.test(positive1$cor~Degradation,data = positive1)
all_kw
kw <- kruskal(positive1$cor, positive1$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('a','b','a')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")

positive_j<-ggplot(data = cor_density[cor_density$cor>0,], aes(x=as.numeric(Degradation),y=cor,color="red")) + 
  geom_smooth(method='lm', size =3, se = FALSE)+
  geom_jitter(size = 0.1, alpha = 0.1)+
  ggtitle(expression(~chi^2==45.807~~P==1.13e-10))+
  scale_color_manual(values = c("red"))+
  xlab("")+ylab("Postive Spearman's Rho")+theme_bw()+
  annotate("text",x=1,y=1.1,label="b",size=5,color="black")+
  annotate("text",x=2,y=1.1,label="a",size=5,color="black")+
  annotate("text",x=3,y=1.1,label="a",size=5,color="black")+
  
  
  scale_x_continuous(breaks = c(1,2,3),labels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))+
  scale_y_continuous(limits = c(0,1.5))+
  theme(strip.text = element_text(size = 10,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=10, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text.x=element_text(colour="black",size=10,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=10,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+theme(legend.position="none")
positive_j

means1<-data.frame(row.names(kw$means),kw$means)
names(means1)[1:2]<-c("Degradation","means")
means1$Degradation<-factor(means1$Degradation,levels = c("Non_degraded","Moderately_degraded","Severely_degraded"))


positive_j_3<-ggplot(data = cor_density[cor_density$cor>0,],
                     aes(x=Degradation, y=cor, fill=Degradation)) +
  geom_half_violin(side = "r", color=NA, alpha=0.4) +
  geom_half_boxplot(side = "r", errorbar.draw = FALSE, width=0.2, linewidth=0.5) +
  geom_half_point_panel(side = "l", shape=21, size=0.4,range_scale=2,alpha=0.7,color="white")+
  xlab("")+ylab("Postive Spearman's Rho")+theme_bw()+
  ggtitle(expression(~chi^2==45.807~~P==1.13e-10))+
  annotate("text",x=1,y=1.1,label="b",size=5,color="black")+
  annotate("text",x=2,y=1.1,label="a",size=5,color="black")+
  annotate("text",x=3,y=1.1,label="a",size=5,color="black")+
  
  annotate("point", x = 1, y =0.3012732,colour = "red", size = 1)+ 
  annotate("point", x = 2, y =0.3346832,colour = "red", size = 1)+ 
  annotate("point", x = 3, y =0.3433166,colour = "red", size = 1)+ 
  
  annotate("segment", x = 1, y =0.3012732,xend  = 2, yend =0.3346832,colour = "red", size = 1)+ 
  annotate("segment", x = 2, y =0.3346832,xend = 3, yend =0.3433166,colour = "red", size = 1)+ 
  
  scale_fill_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_text(size=12,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+
  scale_y_continuous(limits = c(0,1.5))
positive_j_3


psoitive<-cor_density[cor_density$cor>0,]

aggregate(cor~ Degradation, psoitive, mean)

bartlett.test(negative1$cor~Degradation,data = negative1)
all_kw<-kruskal.test(negative1$cor~Degradation,data = negative1)
all_kw
kw <- kruskal(negative1$cor, negative1$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('a','b','b')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")

negative_j<-ggplot(data = cor_density[cor_density$cor<0,], aes(x=as.numeric(Degradation),y=cor*-1,color="blue")) + 
  geom_smooth(method='lm', size =3, se = FALSE)+
  geom_jitter(size = 0.1, alpha = 0.1)+
  ggtitle(expression(~chi^2==31.625~~P==1.357e-07))+
  scale_color_manual(values = c("blue"))+
  xlab("")+ylab("Negative Spearman's Rho * -1")+theme_bw()+
  annotate("text",x=1,y=1.1,label="b",size=5,color="black")+
  annotate("text",x=2,y=1.1,label="a",size=5,color="black")+
  annotate("text",x=3,y=1.1,label="b",size=5,color="black")+
  
  annotate("point", x = 1, y =0.3012732,colour = "red", size = 1)+ 
  annotate("point", x = 2, y =0.3346832,colour = "red", size = 1)+ 
  annotate("point", x = 3, y =0.3433166,colour = "red", size = 1)+ 
  
  annotate("segment", x = 1, y =0.3012732,xend  = 2, yend =0.3346832,colour = "red", size = 1)+ 
  annotate("segment", x = 2, y =0.3346832,xend = 3, yend =0.3433166,colour = "red", size = 1)+ 
  
  scale_x_continuous(breaks = c(1,2,3),labels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))+
  scale_y_continuous(limits = c(0,1.5))+
  theme(strip.text = element_text(size = 10,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=10, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text.x=element_text(colour="black",size=10,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=10,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+theme(legend.position="none")
negative_j

means2<-data.frame(row.names(kw$means),kw$means)
names(means2)[1:2]<-c("Degradation","means")
means2$Degradation<-factor(means2$Degradation,levels = c("Non_degraded","Moderately_degraded","Severely_degraded"))

negative_j_3<-ggplot(cor_density[cor_density$cor<0,],
                     aes(x=Degradation, y=cor*-1, fill=Degradation)) +
  geom_half_violin(side = "r", color=NA, alpha=0.4) +
  geom_half_boxplot(side = "r", errorbar.draw = FALSE, width=0.2, linewidth=0.5) +
  geom_half_point_panel(side = "l", shape=21, size=0.4,range_scale=2,alpha=0.7,color="white")+
  xlab("")+ylab("Negative Spearman's Rho * -1")+theme_bw()+
  ggtitle(expression(~chi^2==31.625~~P==1.357e-07))+
  annotate("text",x=1,y=1.1,label="b",size=5,color="black")+
  annotate("text",x=2,y=1.1,label="a",size=5,color="black")+
  annotate("text",x=3,y=1.1,label="b",size=5,color="black")+
  
  annotate("point", x = 1, y =0.2189389,colour = "red", size = 1)+ 
  annotate("point", x = 2, y =0.2574884,colour = "red", size = 1)+ 
  annotate("point", x = 3, y =0.2268087,colour = "red", size = 1)+ 
  
  annotate("segment", x = 1, y =0.2189389,xend  = 2, yend =0.2574884,colour = "red", size = 1)+ 
  annotate("segment", x = 2, y =0.2574884,xend = 3, yend =0.2268087,colour = "red", size = 1)+ 
  scale_fill_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_text(size=12,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+
  scale_y_continuous(limits = c(0,1.3))
negative_j_3

all_cor_j_3|positive_j_3|negative_j_3

lm_j<-all_cor_j_3|positive_j_3|negative_j_3
lm_j+plot_annotation(tag_levels = "a")&
  theme(plot.tag = element_text(size=20,face="bold"))