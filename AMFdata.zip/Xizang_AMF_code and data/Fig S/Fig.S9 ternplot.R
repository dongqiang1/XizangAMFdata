###root soil tern plot
rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")
library(ggtern)
library(ggplot2)
library(labdsv) 
#############################

rs<-read.csv("root_soil.csv",header=T,row.names = 1) 
rs.d<-rs[,colSums(rs)>0]
amfgroup<-read.csv("amfgroup.csv", header=TRUE, row.names=1)
amfid<-read.csv("otuid.csv", header=TRUE)
gro<-read.csv("amfgroup.csv",header=T,row.names = 1) 
rsgro<-amfgroup[amfgroup$Compartment%in%c("Root","Soil"),]

amf.r<-rs.d[rsgro$Compartment == "Root",]
amf.r<-amf.r[,colSums(amf.r)>0]
t.amf.r<-t(amf.r)
t.amf.r<-data.frame(row.names(t.amf.r), t.amf.r)
names(t.amf.r)[1]<-c("OTU")
id.r<-merge(amfid,t.amf.r,by="OTU")
id.r = id.r[1:3]
gro.r<-rsgro[rsgro$Compartment == "Root" ,]

amf.r.ld<-amf.r[gro.r$Degradation=="Non",]
amf.r.md<-amf.r[gro.r$Degradation=="Moderately",]
amf.r.sd<-amf.r[gro.r$Degradation=="Severely",]
gro.r.ld<-amf.r[gro.r$Degradation=="Non",]
gro.r.md<-amf.r[gro.r$Degradation=="Moderately",]
gro.r.sd<-amf.r[gro.r$Degradation=="Severely",]
gro.r.ld$fa<-"Non"
gro.r.md$fa<-"Moderately"
gro.r.sd$fa<-"Severely"
amf.lms<-data.frame(rbind(amf.r.ld,amf.r.md,amf.r.sd))
gro.r.lms<-data.frame(rbind(gro.r.ld,gro.r.md,gro.r.sd))
amf.lms<-amf.lms[,colSums(amf.lms)>0]
iva <- indval(amf.lms, droplevels(factor(gro.r.lms$fa)))
summary(iva)
ind<-data.frame(iva$pval)    
ind<-data.frame(row.names(ind), ind)
ind<-ind[ind$iva.pval< 0.05,]
aa<-data.frame(row.names(ind),"Indicator")
names(aa)<-c("OTU", "Indicator")
bb<-data.frame(setdiff(id.r$OTU , aa$OTU),"NS")
names(bb)<-c("OTU", "Indicator")
cc<-rbind(aa, bb)
cc<-cc[match(id.r$OTU, cc$OTU),]
IDr<-data.frame(cc, id.r)

l<-data.frame(colSums(amf.r.ld))
l<-data.frame(row.names(l),l)
names(l)<-c("OTU","lsum")
m<-data.frame(colSums(amf.r.md))
m<-data.frame(row.names(m),m)
names(m)<-c("OTU","msum")
s<-data.frame(colSums(amf.r.sd))
s<-data.frame(row.names(s),s)
names(s)<-c("OTU","ssum")

Abundance<-data.frame(row.names(l),l$lsum+m$msum+s$ssum)
names(Abundance)<-c("OTU","Abundance")
Relative_abundance<-Abundance$Abundance/(11329*18)

dar<-data.frame(l$lsum/sum(l$lsum),m$msum/sum(m$msum),s$ssum/sum(s$ssum),Abundance)
dar<-merge(dar,IDr,by="OTU")
#write.csv(dar,file = "dar1.csv")
dar<-read.csv("dar1.csv",header=T )
dar<-dar[dar$Abundance>0,]
dar$Non<-dar$l.lsum.sum.l.lsum.
dar$Moderately<-dar$m.msum.sum.m.msum.
dar$Severely<-dar$s.ssum.sum.s.ssum.
darsig<-dar[dar$Indicator=="Indicator",]
factor(dar$Genus)

Froot_tern<-ggtern(dar,aes(Non,Moderately,Severely,color=Genus,shape = Indicator))+
  geom_point(aes(size=Relative_abundance))+theme_bw()+theme_nomask()+
  scale_color_manual(values=c("green","#FF3300","#9999FF","darkgreen","cyan","#CCFFCC"
                              ,"grey","#0000FF","#FF3399","red","black","navy"))+
  scale_shape_manual(values=c(16,4))+
  labs(title = "a Root")+
  theme( plot.title = element_text(color="black", size=14, face="bold",hjust=0.5), )

Froot_tern

Frootind_tern<-ggtern(darsig,aes(Non,Moderately,Severely,color=Genus,shape = Indicator))+
  geom_point(aes(size=Relative_abundance))+theme_bw()+theme_nomask()+
  scale_color_manual(values=c("green","darkgreen","#0000FF", "red"))+
  scale_shape_manual(values=c(16,4))+
  labs(title = "a Root")+
  theme( plot.title = element_text(color="black", size=14, face="bold",hjust=0.5), )
Frootind_tern

Frootind_tern|Froot_tern


amf.s<-rs.d[rsgro$Compartment == "Soil",]
amf.s<-amf.s[,colSums(amf.s)>0]
t.amf.s<-t(amf.s)
t.amf.s<-data.frame(row.names(t.amf.s), t.amf.s)
names(t.amf.s)[1]<-c("OTU")
id.s<-merge(amfid,t.amf.s,by="OTU")
id.s = id.s[1:3]
gro.s<-rsgro[rsgro$Compartment == "Soil",]
amf.s.ld<-amf.s[gro.s$Degradation=="Non",]
amf.s.md<-amf.s[gro.s$Degradation=="Moderately",]
amf.s.sd<-amf.s[gro.s$Degradation=="Severely",]
gro.s.ld<-amf.s[gro.s$Degradation=="Non",]
gro.s.md<-amf.s[gro.s$Degradation=="Moderately",]
gro.s.sd<-amf.s[gro.s$Degradation=="Severely",]
gro.s.ld$fa<-"Non"
gro.s.md$fa<-"Moderately"
gro.s.sd$fa<-"Severely"
amf.lms<-data.frame(rbind(amf.s.ld,amf.s.md,amf.s.sd))
gro.s.lms<-data.frame(rbind(gro.s.ld,gro.s.md,gro.s.sd))
amf.lms<-amf.lms[,colSums(amf.lms)>0]
iva <- indval(amf.lms, droplevels(factor(gro.s.lms$fa)))
summary(iva)
ind<-data.frame(iva$pval)    
ind<-data.frame(row.names(ind), ind)
ind<-ind[ind$iva.pval<0.05,]
aa<-data.frame(row.names(ind),"Indicator")
names(aa)<-c("OTU", "Indicator")
bb<-data.frame(setdiff(id.s$OTU , aa$OTU),"NS")
names(bb)<-c("OTU", "Indicator")
cc<-rbind(aa, bb)
cc<-cc[match(id.s$OTU, cc$OTU),]
IDs<-data.frame(cc, id.s)

l<-data.frame(colSums(amf.s.ld))
l<-data.frame(row.names(l),l)
names(l)<-c("OTU","lsum")
m<-data.frame(colSums(amf.s.md))
m<-data.frame(row.names(m),m)
names(m)<-c("OTU","msum")
s<-data.frame(colSums(amf.s.sd))
s<-data.frame(row.names(s),s)
names(s)<-c("OTU","ssum")

Abundance<-data.frame(row.names(l),l$lsum+m$msum+s$ssum)
names(Abundance)<-c("OTU","Abundance")
Relative_abundance<-Abundance$Abundance/(11329*18)

das<-data.frame(l$lsum/sum(l$lsum),m$msum/sum(m$msum),s$ssum/sum(s$ssum),Abundance)
das<-merge(das,IDs,by="OTU")
#write.csv(das,file = "das1.csv")
das<-read.csv("das1.csv",header=T )
das<-das[das$Abundance>0,]

das$Non<-das$l.lsum.sum.l.lsum.
das$Moderately<-das$m.msum.sum.m.msum.
das$Severely<-das$s.ssum.sum.s.ssum.
dassig<-das[das$Indicator=="Indicator",]

Fsoil_tern<-ggtern(das,aes(Non,Moderately,Severely,color=Genus,shape = Indicator))+
  geom_point(aes(size=Relative_abundance))+theme_bw()+theme_nomask()+
  scale_color_manual(values=c("green","#FF3300","#9999FF","darkgreen","cyan","#CCFFCC"
                              ,"grey","#0000FF","#FF3399","red","black","navy"))+
  scale_shape_manual(values=c(16,4))+
  labs(title = "b  Soil")+
  theme( plot.title = element_text(color="black", size=14, face="bold",hjust=0.5), )
Fsoil_tern

Fsoilind_tern<-ggtern(dassig,aes(Non,Moderately,Severely,color=Genus,shape = Indicator))+
  geom_point(aes(size=Relative_abundance))+theme_bw()+theme_nomask()+
  scale_color_manual(values=c( "darkgreen","grey","#0000FF","red"))+
  scale_shape_manual(values=c(16,4))+
  labs(title = "b Soil")+
  theme( plot.title = element_text(color="black", size=14, face="bold",hjust=0.5), )
Fsoilind_tern

Frootind_tern|Fsoilind_tern

Froot_tern|Fsoil_tern

(Frootind_tern|Fsoilind_tern)/(Froot_tern|Fsoil_tern)






