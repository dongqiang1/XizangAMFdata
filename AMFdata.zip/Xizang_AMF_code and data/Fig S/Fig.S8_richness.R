setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

library(patchwork)
library(vegan)
library(picante)
library(plyr)
library(scales)
library(tidyr)
library(ggpubr)
library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(ggThemeAssist) 

otuwork<-read.csv("otuwork.csv", header=TRUE ,row.names=1)
richness<- specnumber(otuwork)
#write.csv(richness,file='richness.csv')
richness<-read.csv("richness.csv", header=TRUE)
names(richness)[1]<-c("sample")
amfgroup<-read.csv("amfgroup.csv", header=TRUE)
richness1<-merge(richness,amfgroup,by="sample")


root<-richness1[richness1$Compartment=="Root",]
soil<-richness1[richness1$Compartment=="Soil",]
dominant<-richness1[richness1$Compartment=="Dominant",]
companion<-richness1[richness1$Compartment=="Companion",]

shapiro.test(root$x)
bartlett.test(x~Degradation,data = root)
root_kw<-kruskal.test(x~Degradation,data = root)
root_kw
kw <- kruskal(root$x, root$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('a','a','a')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")
root$Degradation<-factor(root$Degradation,levels = c("Non","Moderately","Severely"))
proot<-ggplot(data=root, aes(x=Degradation, y=x,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  annotate("text",x=2.05,y=98,label=expression(~chi^2==4.895~~P==0.087),size=6,color="red")+
  xlab("")+ylab("Arbuscular mycorrhizal fungal richness")+
  guides(fill=F)+
  facet_grid(.~Compartment,)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(70,100))+
  theme_bw()+
  theme(axis.text=element_text(size=9,face="bold",color="black"),
        axis.title=element_text(size=11,face="bold"),
        strip.text.x = element_text(size =15))+theme(legend.position="none")

proot

shapiro.test(soil$x)
bartlett.test(x~Degradation,data = soil)
soil_kw<-kruskal.test(x~Degradation,data = soil)
soil_kw
kw <- kruskal(soil$x, soil$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('a','a','a')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")
soil$Degradation<-factor(soil$Degradation,levels = c("Non","Moderately","Severely"))
psoil<-ggplot(data=soil, aes(x=Degradation, y=x,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  annotate("text",x=2.05,y=99,label=expression(~chi^2==2.553~~P==0.279),size=6,color="red")+
  xlab("")+ylab("Arbuscular mycorrhizal fungal richness")+
  guides(fill=F)+
  facet_grid(.~Compartment,)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(80,100))+
  theme_bw()+
  theme(axis.text=element_text(size=9,face="bold",color="black"),
        axis.title=element_text(size=11,face="bold"),
        strip.text.x = element_text(size =15))+theme(legend.position="none")
psoil
(proot|psoil)+ plot_annotation(tag_levels = "a")&
  theme(plot.tag = element_text(size=20,face="bold"))


shapiro.test(dominant$x)
bartlett.test(x~Degradation,data = dominant)
dominant_kw<-kruskal.test(x~Degradation,data = dominant)
dominant_kw
kw <- kruskal(dominant$x, dominant$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('b','b','a')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")
dominant$Degradation<-factor(dominant$Degradation,levels = c("Non","Moderately","Severely"))
pdominant<-ggplot(data=dominant, aes(x=Degradation, y=x,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  ggtitle(expression(~chi^2==10.779~~P==0.005))+
  xlab("")+ylab("Arbuscular mycorrhizal fungal richness")+
  guides(fill=F)+
  facet_grid(.~Compartment,)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(40,110))+
  theme_bw()+
  geom_text(data=kwsig,aes(x=Degradation,y=dominant.x+std+14),label=kwsig$kwsig,size=6,color="black")+
  theme(axis.text=element_text(size=9,face="bold",color="black"),
        axis.title=element_text(size=11,face="bold"),
        strip.text.x = element_text(size =15),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+theme(legend.position="none")
pdominant

shapiro.test(companion$x)
bartlett.test(x~Degradation,data =companion)
companion_kw<-kruskal.test(x~Degradation,data = companion)
companion_kw
kw <- kruskal(companion$x, companion$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('b','c','a')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")
companion$Degradation<-factor(companion$Degradation,levels = c("Non","Moderately","Severely"))
pcompanion<-ggplot(data=companion, aes(x=Degradation, y=x,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  ggtitle(expression(~chi^2==13.066~~P==0.001))+
  xlab("")+ylab("Arbuscular mycorrhizal fungal richness")+
  guides(fill=F)+
  facet_grid(.~Compartment,)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(35,105))+
  theme_bw()+
  geom_text(data=kwsig,aes(x=Degradation,y=companion.x+std+12),label=kwsig$kwsig,size=6,color="black")+
  theme(axis.text=element_text(size=9,face="bold",color="black"),
        axis.title=element_text(size=11,face="bold"),
        strip.text.x = element_text(size =15),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+theme(legend.position="none")
pcompanion

f_richness<-(proot|psoil)/(pdominant|pcompanion)
f_richness+plot_annotation(tag_levels = "a")&
  theme(plot.tag = element_text(size=20,face="bold"))

#######################################################################

otuwork<-read.csv("otuwork.csv", header=TRUE ,row.names=1)
S <- specnumber(otuwork)
write.csv(S,file='S.csv')

shannon <- diversity(otuwork, index = "shannon")
J <- shannon/log(S)
head(J)
richness_shannon_j<-data.frame(S,shannon,J)
#write.csv(richness_shannon_j,file='richness_shannon_j.csv')
richness<-read.csv("richness_shannon_j.csv", header=TRUE)
names(richness)[1]<-c("sample")

amfgroup<-read.csv("amfgroup.csv", header=TRUE)
richness1<-merge(richness,amfgroup,by="sample")

root<-richness1[richness1$Compartment=="Root",]
soil<-richness1[richness1$Compartment=="Soil",]


shapiro.test(root$shannon)
bartlett.test(shannon~Degradation,data = root)
aov1<-aov(shannon~Degradation,data = root)
summary(aov1)
root_kw<-kruskal.test(shannon~Degradation,data = root)
root_kw
kw <- kruskal(root$shannon, root$Degradation, p.adj = 'BH')
kw

shapiro.test(root$J)
bartlett.test(J~Degradation,data = root)
aov1<-aov(J~Degradation,data = root)
summary(aov1)
root_kw<-kruskal.test(J~Degradation,data = root)
root_kw
kw <- kruskal(root$J, root$Degradation, p.adj = 'BH')
kw
root$Degradation<-factor(root$Degradation,levels = c("Non","Moderately","Severely"))
proot_j<-ggplot(data=root, aes(x=Degradation, y=J,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  annotate("text",x=2.05,y=0.8,label=expression(~chi^2==2.538~~P==0.281),size=6,color="red")+
  xlab("")+ylab("Arbuscular mycorrhizal fungal evenness")+
  guides(fill=F)+
  facet_grid(.~Compartment,)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(0.2,0.9))+
  theme_bw()+
  theme(axis.text=element_text(size=9,face="bold",color="black"),
        axis.title=element_text(size=11,face="bold"),
        strip.text.x = element_text(size =15))+theme(legend.position="none")

proot_j

shapiro.test(soil$shannon)
bartlett.test(shannon~Degradation,data = soil)
aov1<-aov(shannon~Degradation,data =soil)
summary(aov1)
root_kw<-kruskal.test(shannon~Degradation,data = soil)
root_kw
kw <- kruskal(soil$shannon, soil$Degradation, p.adj = 'BH')
kw

shapiro.test(soil$J)
bartlett.test(J~Degradation,data = soil)
aov1<-aov(J~Degradation,data = soil)
summary(aov1)
root_kw<-kruskal.test(J~Degradation,data =soil)
root_kw
kw <- kruskal(soil$J, soil$Degradation, p.adj = 'BH')
kw
soil$Degradation<-factor(soil$Degradation,levels = c("Non","Moderately","Severely"))
psoil_j<-ggplot(data=soil, aes(x=Degradation, y=J,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  annotate("text",x=2.05,y=0.59,label=expression(~chi^2==0.011~~P==0.994),size=6,color="red")+
  xlab("")+ylab("Arbuscular mycorrhizal fungal evenness")+
  guides(fill=F)+
  facet_grid(.~Compartment,)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(0.45,0.6))+
  theme_bw()+
  theme(axis.text=element_text(size=9,face="bold",color="black"),
        axis.title=element_text(size=11,face="bold"),
        strip.text.x = element_text(size =15))+theme(legend.position="none")
psoil_j

(proot|psoil)/(proot_j|psoil_j)+ plot_annotation(tag_levels = "a")&
  theme(plot.tag = element_text(size=20,face="bold"))


