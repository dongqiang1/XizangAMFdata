rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(patchwork)
library(vegan)
library(scales)
library(ggThemeAssist) 
library(plyr)
library(picante)
library(ggpubr)
library(ggpie)

otuwork<-read.csv("otuwork.csv", header=TRUE, row.names=1)
amfid<-read.csv("otuid.csv", header=TRUE)
factor(amfid$Genus)

otureads<-data.frame(t(otuwork))
otureads1<-data.frame(row.names(otureads),otureads)
names(otureads1)[1]<-c('OTU')
otureads2<-merge(amfid,otureads1,by='OTU')
otureads3<-data.frame(rowSums(otureads2[,4:75]))
otureads4<-aggregate(otureads2[,4:75],by=list(Genus=otureads2$Genus),sum)
otureads5<-data.frame(otureads4$Genus,rowSums(otureads4[2:73]))
names(otureads5)[1:2]<-c('Genus','Reads')


col10<-c("blue","#ff00ff", "deepskyblue", "#00ff00", "red",
         "navy", "bisque","darkgreen","maroon3", "black","grey","#FF3300")
ggplot(otureads5, aes(x="", y=Reads, fill=Genus)) +
  geom_bar(stat="identity", width=1,color="white") +
  coord_polar("y", start=0)+
  theme_void()+
  geom_text(aes(y = Reads, label = Genus), color = "white")+
  scale_fill_manual(values = col10) 




otureads2$Genus<-factor(otureads2$Genus,levels = c( "Claroideoglomus" ,
                                                    "Acaulospora",     
                                                    "Ambispora" , 
                                                    "Archaeospora" ,   
                                                    "Diversispora"  ,  
                                                    "Funneliformis" ,
                                                    "Scutellospora" ,
                                                    "Glomus"   ,       
                                                    "Paraglomus", 
                                                    "Rhizophagus", 
                                                    "Glomerales",
                                                    "Septoglomus"))


ggpie(data =otureads2, group_key = "Genus", count_type = "full",label_info = "all", label_type = "horizon", label_split = NULL,
      label_size = 4, label_pos = "out")
fs_otu_number<-ggdonut(data =otureads2, group_key = "Genus", count_type = "full",label_info = "all", label_type = "horizon", label_split = NULL,
      label_size =4, label_pos = "out" ,border_color="white",r0 =1.3,label_gap =1)+
  scale_fill_manual(values = col10) +
  theme(strip.text = element_text(size =25,face="bold"),
        legend.title = element_text(colour="black", size=13, face="bold"),
        legend.text = element_text(colour="black", size=13, face="bold"))+ labs(fill = " ")
fs_otu_number

Acaulospora<-       data.frame(rep(otureads5[1,1],otureads5[1,2]))
names(Acaulospora)[1]<-c('Reads')
Ambispora<-         data.frame(rep(otureads5[2,1],otureads5[2,2]))
names(Ambispora)[1]<-  c('Reads')
Archaeospora<-      data.frame(rep(otureads5[3,1],otureads5[3,2]))
names(Archaeospora)[1]<-c('Reads')
Claroideoglomus<-   data.frame(rep(otureads5[4,1],otureads5[4,2]))
names(Claroideoglomus)[1]<-c('Reads')
Diversispora<-      data.frame(rep(otureads5[5,1],otureads5[5,2]))
names(Diversispora)[1]<-c('Reads')
Funneliformis<-    data.frame(rep(otureads5[6,1],otureads5[6,2]))
names(Funneliformis)[1]<-c('Reads')

Glomerales<-            data.frame(rep(otureads5[7,1],otureads5[7,2]))
names(Glomerales)[1]<-c('Reads')

Glomus<-            data.frame(rep(otureads5[8,1],otureads5[8,2]))
names(Glomus)[1]<-c('Reads')

Paraglomus<-        data.frame(rep(otureads5[9,1],otureads5[9,2])) 
names(Paraglomus)[1]<-c('Reads')
Rhizophagus<-       data.frame(rep(otureads5[10,1],otureads5[10,2]))
names(Rhizophagus)[1]<-c('Reads')
Scutellospora<-     data.frame(rep(otureads5[11,1],otureads5[11,2]))
names(Scutellospora)[1]<-c('Reads')

Septoglomus<-     data.frame(rep(otureads5[12,1],otureads5[12,2]))
names(Septoglomus)[1]<-c('Reads')

a<-rbind(Acaulospora,Ambispora,Archaeospora,Claroideoglomus,Diversispora,Funneliformis,Glomus,Glomerales,
         Paraglomus,Rhizophagus,Scutellospora,Septoglomus)


a$Reads<-factor(a$Reads,levels =      c( "Claroideoglomus" ,
                                         "Acaulospora",     
                                         "Ambispora" , 
                                         "Archaeospora" ,   
                                         "Diversispora"  ,  
                                         "Funneliformis" ,
                                         "Scutellospora" ,
                                         "Glomus"   ,       
                                         "Paraglomus", 
                                         "Rhizophagus", 
                                         "Glomerales",
                                         "Septoglomus"))

fs_otu_reads<-ggdonut(data =a, group_key = "Reads", count_type = "full",label_info = "all", label_type = "horizon", label_split = NULL,
        label_size =4, label_pos = "out" ,border_color="white",r0 =1.3,label_gap =1)+
  scale_fill_manual(values = col10) +
  theme(strip.text = element_text(size =25,face="bold"),
        legend.title = element_text(colour="black", size=13, face="bold"),
        legend.text = element_text(colour="black", size=13, face="bold"))+ labs(fill = " ")
fs_otu_reads

