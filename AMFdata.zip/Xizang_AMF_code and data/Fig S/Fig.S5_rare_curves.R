setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

library(vegan)
library(ggplot2)
library(ggpubr)
library(ggsci)
library(patchwork)


otu<-read.csv("amfotu.csv", header=TRUE,row.names=1)
alpha_index <- function(x, method = 'richness', tree = NULL, base = exp(1)) {
  if (method == 'richness') result <- rowSums(x > 0)
  else if (method == 'chao1') result <- estimateR(x)[2, ]	
  else if (method == 'ace') result <- estimateR(x)[4, ]	
  else if (method == 'shannon') result <- diversity(x, index = 'shannon', base = base)	
  else if (method == 'simpson') result <- diversity(x, index = 'simpson')	
  else if (method == 'pielou') result <- diversity(x, index = 'shannon', base = base) / log(estimateR(x)[1, ], base)	
  result
}


alpha_curves <- function(x, step, method = 'richness', rare = NULL, tree = NULL, base = exp(1)) {
  x_nrow <- nrow(x)
  if (is.null(rare)) rare <- rowSums(x) else rare <- rep(rare, x_nrow)
  alpha_rare <- list()
  
  for (i in 1:x_nrow) {
    step_num <- seq(0, rare[i], step)
    if (max(step_num) < rare[i]) step_num <- c(step_num, rare[i])
    
    alpha_rare_i <- NULL
    for (step_num_n in step_num) alpha_rare_i <- c(alpha_rare_i, alpha_index(x = rrarefy(x[i, ], step_num_n), method = method, tree = tree, base = base))
    names(alpha_rare_i) <- step_num
    alpha_rare <- c(alpha_rare, list(alpha_rare_i))
  }
  names(alpha_rare) <- rownames(x)
  alpha_rare
}

shannon_index <- alpha_index(otu, method = 'shannon', base = exp(1))
shannon_curves <- alpha_curves(otu, step = 1000, method = 'shannon', base = exp(1))
richness_curves <- alpha_curves(otu, step = 1000, method = 'richness')

plot_richness <- data.frame()
for (i in names(richness_curves)) {
  richness_curves_i <- (richness_curves[[i]])
  richness_curves_i <- data.frame(rare = names(richness_curves_i), alpha = richness_curves_i, sample = i, stringsAsFactors = FALSE)
  plot_richness <- rbind(plot_richness, richness_curves_i)
}

rownames(plot_richness) <- NULL
plot_richness$rare <- as.numeric(plot_richness$rare)
plot_richness$alpha <- as.numeric(plot_richness$alpha)

ggplot(plot_richness, aes(rare, alpha, color = sample)) +
  geom_line() +
  labs(x = 'Number of sequences', y = 'Richness', color = NULL) +
  theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.key = element_rect(fill = 'transparent')) +
  geom_vline(xintercept = min(rowSums(otu)), linetype = 2) 



ggplot(plot_richness, aes(rare, alpha, color = sample)) +
  geom_smooth(se=F)+
  labs(x = 'Number of sequences', y = 'Richness', color = NULL) +
  theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.key = element_rect(fill = 'transparent')) +
  geom_vline(xintercept = min(rowSums(otu)), linetype = 2) 




amfgroup<-read.csv("amfgroup.csv", header=TRUE)
rare<-merge(plot_richness,amfgroup,by="sample")
#write.csv(rare,file='rare.csv')


root<-rare[rare$Compartment%in%c("Root"),]
soil<-rare[rare$Compartment%in%c("Soil"),]
dominant<-rare[rare$Compartment%in%c("Dominant"),]
companion<-rare[rare$Compartment%in%c("Companion"),]



mycolors1<-c("greenyellow","green","green1","green2","green3","green4",
             "grey70","grey60","grey50","grey40","grey30","grey20",
             "blueviolet","blue","blue1","blue2","blue3","blue4")
root$Degradation<- factor(root$Degradation,levels = c("Non","Moderately","Severely"))  
root$sample<- factor(root$sample,levels = c("ND_Root_1","ND_Root_2","ND_Root_3","ND_Root_4","ND_Root_5","ND_Root_6",
                                            "MD_Root_1","MD_Root_2","MD_Root_3","MD_Root_4","MD_Root_5","MD_Root_6",
                                            "SD_Root_1","SD_Root_2","SD_Root_3","SD_Root_4","SD_root_5","SD_Root_6"))
root_line<-ggplot(root, aes(rare, alpha, color =sample)) +
  geom_smooth(se=F)+
  labs(x = 'Number of sequences', y = 'Number of OTUs', color = NULL) +
  guides(fill=F)+
  facet_grid(.~Compartment,)+
  annotate('text', label = ' ', x =40000, y =40, angle=0, size =5,color="black")+
  theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), 
        legend.key = element_rect(fill = 'transparent'),legend.position = "none",
        axis.text.x=element_text(size=8,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        strip.text.x = element_text(size =15))+
  geom_vline(xintercept = min(rowSums(otu)), linetype = 2)  +
  scale_color_manual(values= mycolors1)
root_line


soil$Degradation<- factor(soil$Degradation,levels = c("Non","Moderately","Severely"))   
soil$sample<- factor(soil$sample,levels = c("ND_Soil_1","ND_Soil_2","ND_Soil_3","ND_Soil_4","ND_Soil_5","ND_Soil_6",
                                            "MD_Soil_1","MD_Soil_2","MD_Soil_3","MD_Soil_4","MD_Soil_5","MD_Soil_6",
                                            "SD_Soil_1","SD_Soil_2","SD_Soil_3","SD_Soil_4","SD_Soil_5","SD_Soil_6"))
soil_line<-ggplot(soil, aes(rare, alpha, color =sample)) +
  geom_smooth(se=F)+
  labs(x = 'Number of sequences', y = 'Number of OTUs', color = NULL) +
  guides(fill=F)+
  facet_grid(.~Compartment,)+
  annotate('text', label = ' ', x =40000, y =40, angle=0, size =5,color="black")+
  theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), 
        legend.key = element_rect(fill = 'transparent'),legend.position = "none",        
        axis.text.x=element_text(size=8,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        strip.text.x = element_text(size =15)) +
  geom_vline(xintercept = min(rowSums(otu)), linetype = 2)  +
  scale_color_manual(values= mycolors1)
soil_line





