setwd("C:/Users/DQ/Desktop/文章2/degradation_data")
library(tidyverse)
library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(patchwork)
library(vegan)
library(scales)
library(ggThemeAssist) 
library(plyr)
library(picante)
library(ggpubr)
library(ggtext)

property<-read.csv("soil_plant_property.csv",header = T)
str(property)
df_l <- property %>% pivot_longer(cols = 3:16, names_to = "variables", values_to = "value") %>% dplyr::mutate_if(is.character, as.factor)
str(df_l)
library(rstatix)
df_l %>% group_by(variables,Degradation) %>% shapiro_test(value)
df_l %>% group_by(variables) %>% levene_test(value ~ Degradation)

AP<-property[,c('sample','Degradation','AP')]
shapiro.test(AP$AP)
bartlett.test(AP~Degradation,data = AP)
aov1<-aov(AP~Degradation,data =AP)
summary(aov1)
tukey<-TukeyHSD(aov1)
sig0<-LSD.test(aov1,"Degradation")
sig0
sig0<-data.frame(sig0$means)
sig0<-data.frame(row.names(sig0),sig0)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
sig<-c('a','ab','b')
sig1<-data.frame(sig0,sig)
names(sig1)[1]<-c("Degradation")
AP$Degradation<-factor(AP$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_AP<-ggplot(data=AP, aes(x=Degradation, y=AP,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  geom_point()+
  annotate("text",x=2.05,y=28,label=expression(~F==6.616~~P==0.009),size=4,color="red")+
  xlab(" ")+
  ylab(bquote(AP~(mg/kg)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=sig1,aes(x=Degradation,y=AP+std+5),label=sig1$sig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_AP

NH4_N<-property[,c('sample','Degradation','NH4_N')]
shapiro.test(NH4_N$NH4_N)
bartlett.test(NH4_N~Degradation,data =NH4_N)
NH4_N_kw<-kruskal.test(NH4_N~Degradation,data =NH4_N)
NH4_N_kw
kw<- kruskal(NH4_N$NH4_N, NH4_N$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('a','a','b')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")
NH4_N$Degradation<-factor(NH4_N$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_NH4_N<-ggplot(data=NH4_N, aes(x=Degradation, y=NH4_N,color=Degradation))+
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+ 
  geom_point()+
  annotate("text",x=2.05,y=1.9,label=expression(~chi^2==12.341~~P==0.002),size=4,color="red")+
  xlab(" ")+
  ylab(bquote(NH4_N~(mg/kg)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=kwsig,aes(x=Degradation,y=NH4_N.NH4_N+std+0.6),label=kwsig$kwsig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_NH4_N

NO3_N<-property[,c('sample','Degradation','NO3_N')]
shapiro.test(NO3_N$NO3_N)
bartlett.test(NO3_N~Degradation,data = NO3_N)
NO3_N_kw<-kruskal.test(NO3_N~Degradation,data =NO3_N)
NO3_N_kw
kw<- kruskal(NO3_N$NO3_N, NO3_N$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('b','a','b')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")
NO3_N$Degradation<-factor(NO3_N$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_NO3_N<-ggplot(data=NO3_N, aes(x=Degradation, y=NO3_N,color=Degradation))+
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+ 
  geom_point()+
  annotate("text",x=2.05,y=33,label=expression(~chi^2==8.982~~P==0.011),size=4,color="red")+
  xlab(" ")+
  ylab(bquote(NO3_N~(mg/kg)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=kwsig,aes(x=Degradation,y=NO3_N.NO3_N +std+8),label=kwsig$kwsig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_NO3_N

SOC<-property[,c('sample','Degradation','SOC')]
shapiro.test(SOC$SOC)
bartlett.test(SOC~Degradation,data = SOC)
aov1<-aov(SOC~Degradation,data =SOC)
summary(aov1)
tukey<-TukeyHSD(aov1)
sig0<-LSD.test(aov1,"Degradation")
sig0
sig0<-data.frame(sig0$means)
sig0<-data.frame(row.names(sig0),sig0)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
sig<-c('a','a','b')
sig1<-data.frame(sig0,sig)
names(sig1)[1]<-c("Degradation")
SOC$Degradation<-factor(SOC$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_SOC<-ggplot(data=SOC, aes(x=Degradation, y=SOC,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  geom_point()+
  annotate("text",x=2.05,y=78,label=expression(~F==5.662~~P==0.015),size=4,color="red")+
  xlab(" ")+
  ylab(bquote(SOC~(g/kg)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=sig1,aes(x=Degradation,y=SOC+std+9),label=sig1$sig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_SOC

TP<-property[,c('sample','Degradation','TP')]
shapiro.test(TP$TP)
bartlett.test(TP~Degradation,data = TP)
aov1<-aov(TP~Degradation,data =TP)
summary(aov1)
tukey<-TukeyHSD(aov1)
sig0<-LSD.test(aov1,"Degradation")
sig0
sig0<-data.frame(sig0$means)
sig0<-data.frame(row.names(sig0),sig0)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
sig<-c('ab','a','b')
sig1<-data.frame(sig0,sig)
names(sig1)[1]<-c("Degradation")
TP$Degradation<-factor(TP$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_TP<-ggplot(data=TP, aes(x=Degradation, y=TP,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  geom_point()+
  annotate("text",x=2.05,y=0.37,label=expression(~F==3.588~~P== 0.053),size=4,color="red")+
  xlab(" ")+
  ylab(bquote(TP~(g/kg)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(0.22,0.38))+
  theme_bw()+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_TP

TN<-property[,c('sample','Degradation','TN')]
shapiro.test(TN$TN)
bartlett.test(TN~Degradation,data =TN)
aov1<-aov(TN~Degradation,data =TN)
summary(aov1)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
sig0<-LSD.test(aov1,"Degradation")
sig0
sig0<-data.frame(sig0$means)
sig0<-data.frame(row.names(sig0),sig0)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
sig<-c('a','ab','b')
sig1<-data.frame(sig0,sig)
names(sig1)[1]<-c("Degradation")
TN$Degradation<-factor(TN$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_TN<-ggplot(data=TN, aes(x=Degradation, y=TN,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  geom_point()+
  annotate("text",x=2.05,y=9,label=expression(~F==6.658~~P== 0.009),size=4,color="red")+
  xlab(" ")+
  ylab(bquote(TN~(g/kg)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=sig1,aes(x=Degradation,y=TN+std+1.4),label=sig1$sig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_TN

pH<-property[,c('sample','Degradation','pH')]
shapiro.test(pH$pH)
bartlett.test(pH~Degradation,data =pH)
aov1<-aov(pH~Degradation,data =pH)
summary(aov1)
sig0<-LSD.test(aov1,"Degradation")
sig0
sig0<-data.frame(sig0$means)
sig0<-data.frame(row.names(sig0),sig0)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
sig<-c('b','a','a')
sig1<-data.frame(sig0,sig)
names(sig1)[1]<-c("Degradation")
pH$Degradation<-factor(pH$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_pH<-ggplot(data=pH, aes(x=Degradation, y=pH,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  geom_point()+
  annotate("text",x=2.05,y=7,label=expression(~F==7.098~~P== 0.007),size=4,color="red")+
  xlab(" ")+
  ylab(bquote(pH))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=sig1,aes(x=Degradation,y=pH+std+0.2),label=sig1$sig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_pH

EEG<-property[,c('sample','Degradation','EEG')]
shapiro.test(EEG$EEG)
bartlett.test(EEG~Degradation,data =EEG)
aov1<-aov(EEG~Degradation,data =EEG)
summary(aov1)
sig0<-LSD.test(aov1,"Degradation")
sig0
sig0<-data.frame(sig0$means)
sig0<-data.frame(row.names(sig0),sig0)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
sig<-c('a','a','b')
sig1<-data.frame(sig0,sig)
names(sig1)[1]<-c("Degradation")
EEG$Degradation<-factor(EEG$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_EEG<-ggplot(data=EEG, aes(x=Degradation, y=EEG,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  geom_point()+
  annotate("text",x=2.05,y=2.3,label=expression(~F==10.140~~P== 0.002),size=4,color="red")+
  xlab(" ")+
  ylab(bquote(EE-GRSP~(mg/g)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=sig1,aes(x=Degradation,y=EEG+std+0.3),label=sig1$sig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_EEG

TEG<-property[,c('sample','Degradation','TEG')]
shapiro.test(TEG$TEG)
bartlett.test(TEG~Degradation,data =TEG)
aov1<-aov(TEG~Degradation,data =TEG)
summary(aov1)
sig0<-LSD.test(aov1,"Degradation")
sig0
sig0<-data.frame(sig0$means)
sig0<-data.frame(row.names(sig0),sig0)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
sig<-c('a','a','b')
sig1<-data.frame(sig0,sig)
names(sig1)[1]<-c("Degradation")
TEG$Degradation<-factor(TEG$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_TEG<-ggplot(data=TEG, aes(x=Degradation, y=TEG,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  geom_point()+
  annotate("text",x=2.05,y=6.7,label=expression(~F==5.123~~P== 0.020),size=4,color="red")+
  xlab(" ")+
  ylab(bquote(T-GRSP~(mg/g)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=sig1,aes(x=Degradation,y=TEG+std+0.8),label=sig1$sig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_TEG

f_soil_property<-(f_AP|f_NH4_N|f_NO3_N)/(f_SOC|f_TN|f_pH)/(f_EEG|f_TEG|f_TP)
f_soil_property+plot_annotation(tag_levels = "a")&
  theme(plot.tag = element_text(size=20,face="bold"))

#################################################################################################

Plant_above_biomass<-property[,c('sample','Degradation','Plant_above_biomass')]
shapiro.test(Plant_above_biomass$Plant_above_biomass)
bartlett.test(Plant_above_biomass~Degradation,data =Plant_above_biomass)
Plant_above_biomass_kw<-kruskal.test(Plant_above_biomass~Degradation,data =Plant_above_biomass)
Plant_above_biomass_kw
kw<- kruskal(Plant_above_biomass$Plant_above_biomass, Plant_above_biomass$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('b','a','c')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")
Plant_above_biomass$Degradation<-factor(Plant_above_biomass$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_Plant_above_biomass<-ggplot(data=Plant_above_biomass, aes(x=Degradation, y=Plant_above_biomass,color=Degradation))+
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+ 
  geom_point()+
  annotate("text",x=2.05,y=0.27,label=expression(~chi^2==15.332~~P==0.0005),size=4,color="red")+
  xlab(" ")+
  ylab(bquote(Plant~aboveground~biomass~(kg/m^2)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=kwsig,aes(x=Degradation,y=Plant_above_biomass.Plant_above_biomass+std+0.05),label=kwsig$kwsig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_Plant_above_biomass

Plant_below_biomass<-property[,c('sample','Degradation','Plant_below_biomass')]
shapiro.test(Plant_below_biomass$Plant_below_biomass)
bartlett.test(Plant_below_biomass~Degradation,data =Plant_below_biomass)
Plant_below_biomass_kw<-kruskal.test(Plant_below_biomass~Degradation,data =Plant_below_biomass)
Plant_below_biomass_kw
kw<- kruskal(Plant_below_biomass$Plant_below_biomass, Plant_below_biomass$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('b','a','c')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")
Plant_below_biomass$Degradation<-factor(Plant_below_biomass$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_Plant_below_biomass<-ggplot(data=Plant_below_biomass, aes(x=Degradation, y=Plant_below_biomass,color=Degradation))+
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+ 
  geom_point()+
  annotate("text",x=2.05,y=19,label=expression(~chi^2==15.158~~P==0.0005),size=4,color="red")+
  xlab(" ")+
  ylab(bquote(Plant~belowground~biomass~(kg/m^2)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=kwsig,aes(x=Degradation,y=Plant_below_biomass.Plant_below_biomass+std+2),label=kwsig$kwsig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_Plant_below_biomass

Plant_species_richness<-property[,c('sample','Degradation','Plant_species_richness')]
shapiro.test(Plant_species_richness$Plant_species_richness)
bartlett.test(Plant_species_richness~Degradation,data =Plant_species_richness)
aov1<-aov(Plant_species_richness~Degradation,data =Plant_species_richness)
summary(aov1)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
sig0<-LSD.test(aov1,"Degradation")
sig0
sig0<-data.frame(sig0$means)
sig0<-data.frame(row.names(sig0),sig0)
tukey<-TukeyHSD(aov1)
sig<-c('a','a','b')
sig1<-data.frame(sig0,sig)
names(sig1)[1]<-c("Degradation")
Plant_species_richness$Degradation<-factor(Plant_species_richness$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_Plant_species_richness<-ggplot(data=Plant_species_richness, aes(x=Degradation, y=Plant_species_richness,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  geom_point()+
  annotate("text",x=2.05,y=14,label=expression(~F==20.95~~P==4.54e-05),size=4,color="red")+
  xlab(" ")+
  ylab("Plant species richness")+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=sig1,aes(x=Degradation,y=Plant_species_richness+std+1.3),label=sig1$sig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_Plant_species_richness

Plant_community_coverage<-property[,c('sample','Degradation','Plant_community_coverage')]
shapiro.test(Plant_community_coverage$Plant_community_coverage)
bartlett.test(Plant_community_coverage~Degradation,data =Plant_community_coverage)
aov1<-aov(Plant_community_coverage~Degradation,data =Plant_community_coverage)
summary(aov1)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
sig0<-LSD.test(aov1,"Degradation")
sig0
sig0<-data.frame(sig0$means)
sig0<-data.frame(row.names(sig0),sig0)
tukey<-TukeyHSD(aov1)
sig<-c('b','a','c')
sig1<-data.frame(sig0,sig)
names(sig1)[1]<-c("Degradation")
Plant_community_coverage$Degradation<-factor(Plant_community_coverage$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_Plant_community_coverage<-ggplot(data=Plant_community_coverage, aes(x=Degradation, y=Plant_community_coverage,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  geom_point()+
  annotate("text",x=2.05,y=109,label=expression(~F==161.1~~P==7.27e-11),size=4,color="red")+
  xlab(" ")+
  ylab("Plant community coverage (%)")+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=sig1,aes(x=Degradation,y=Plant_community_coverage+std+8),label=sig1$sig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_Plant_community_coverage

Bareland <-property[,c('sample','Degradation','Bareland')]
shapiro.test(Bareland $Bareland )
bartlett.test(Bareland ~Degradation,data =Bareland )
Bareland_kw<-kruskal.test(Bareland~Degradation,data =Bareland)
Bareland_kw
kw<- kruskal(Bareland$Bareland, Bareland$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('b','c','a')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")
Bareland$Degradation<-factor(Bareland$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
f_Bareland<-ggplot(data=Bareland, aes(x=Degradation, y=Bareland,color=Degradation))+
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+ 
  geom_point()+
  annotate("text",x=2.05,y=100,label=expression(~chi^2==15.158~~P==0.0005),size=4,color="red")+
  xlab(" ")+
  ylab("Bareland area (%)")+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  geom_text(data=kwsig,aes(x=Degradation,y=Bareland.Bareland+std+9),label=kwsig$kwsig,size=6,color="black")+
  theme(strip.text = element_text(size = 15,face="bold"),
        axis.text=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
f_Bareland

######################################### plant beta diversity
plant<-read.csv("plant_species.csv", header=TRUE, row.names=1)
S1 <- specnumber(plant)
(raremax1 <- min(rowSums(plant)))
#plant <- rrarefy(plant, raremax1)
#write.csv(plant,file ="plant.csv")
plant<-read.csv("plant.csv", header=TRUE, row.names=1)


gro<-read.csv("amfgroup.csv",header=T,row.names = 1) 
gro<-gro[gro$Compartment%in%c("Soil"),]

nd<-plant[gro$Degradation%in%c("Non"),]
n_dis<-decostand(nd,"hellinger")
n_dis<-vegdist(n_dis,method="bray")

md<-plant[gro$Degradation%in%c("Moderately"),]
m_dis<-decostand(md,"hellinger")
m_dis<-vegdist(m_dis,method="bray")

sd<-plant[gro$Degradation%in%c("Severely"),]
s_dis<-decostand(sd,"hellinger")
s_dis<-vegdist(s_dis,method="bray")

index<-rbind(n_dis,m_dis,s_dis)
rownames(index)<-c("Non","Moderately","Severely")
data1<-melt(index)
names(data1)[1:3]<-c("Degradation","level","Beta_diversity")

shapiro.test(data1$Beta_diversity)
bartlett.test(data1$Beta_diversity~Degradation,data =data1)
aov1<-aov(data1$Beta_diversity~Degradation,data =data1)
summary(aov1)

sig0<-LSD.test(aov1,"Degradation")
sig0<-data.frame(sig0$means)
sig0<-data.frame(row.names(sig0),sig0)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld

p_plant_beta<-ggplot(data =data1, aes(x=Degradation,y=Beta_diversity,color=Degradation))+
  stat_boxplot(geom="errorbar",position=position_dodge(width=0.2),width=0.3)+
  geom_boxplot()+
  geom_point()+
  theme_bw()+
  xlab("")+ylab("Beta diversity")+
  annotate("text",x=2.05,y=0.4,label=expression(~F==3.272~~P==0.048),size=4,color="red")+
  annotate("text",x=1,y=0.37,label="ab",size=5,color="black")+
  annotate("text",x=2,y=0.37,label="a",size=5,color="black")+
  annotate("text",x=3,y=0.36,label="b",size=5,color="black")+
  theme(strip.text = element_text(size =12,face="bold"),
        legend.title = element_text(colour="black", size=10, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"))+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")
p_plant_beta

pempty <- ggplot() + 
  theme_void()
f_plant_property<-(f_Plant_above_biomass|f_Plant_below_biomass|f_Plant_species_richness)/(f_Plant_community_coverage|f_Bareland|p_plant_beta)
f_plant_property+plot_annotation(tag_levels = "a")&
  theme(plot.tag = element_text(size=20,face="bold"))





