rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

library(vegan)
library(ggplot2)
library(ape)
library(splitstackshape)
library(reshape2)
library(dplyr)
library(colorRamps)
library(tidyverse)
library(patchwork)

plant<-read.csv("plant_species.csv", header=TRUE, row.names=1)
S1 <- specnumber(plant)
(raremax1 <- min(rowSums(plant)))
#plant <- rrarefy(plant, raremax1)
#write.csv(plant,file ="plant.csv")
plant<-read.csv("plant.csv", header=TRUE, row.names=1)
gro<-read.csv("amfgroup.csv",header=T,row.names = 1) 
gro<-gro[gro$Compartment%in%c("Soil"),]

degradation<-gro$Degradation
ado<-adonis(plant~degradation,permutations=999,distance="bray")
ado$aov.tab

community_hel <- decostand(plant, method = 'hellinger')
bc<-vegdist(community_hel,method="bray")
bc <- as.matrix(bc)
pcoa <- cmdscale(bc, eig=T)
eig <- summary(eigenvals(pcoa))
axis <- paste0("PCO", 1:ncol(eig))
eig <- data.frame(Axis = axis, t(eig)[, -3])
head(eig)
pco1 = round(eig[1, 3] * 100, 2)
pco2 = round(eig[2, 3] * 100, 2)
xlab = paste0("PCO1 (",pco1,"%)")
ylab = paste0("PCO2 (",pco2,"%)")
pcoa_points = as.data.frame(pcoa$points)
pcoa_points<-data.frame(row.names(pcoa_points),pcoa_points)
names(pcoa_points)[1]<-c("sample")
gro<-data.frame(row.names(gro),gro)
names(gro)[1]<-c("sample")
pcoa_points_plant<-merge(pcoa_points, gro,by="sample")

pcoa_points_plant$Degradation<-factor(pcoa_points_plant$Degradation,levels = c("Non","Moderately","Severely"))
F_PCOA_plant<-ggplot(pcoa_points_plant,aes(x=V1,y=V2,shape=Degradation))+
  geom_point(size=5,alpha=.6)+
  labs(x=xlab,y=ylab)+
  scale_shape_manual(values=c(15,17,16))+
  theme_bw()+
  #annotate("text",x=0.165,y=-0.12,label="Compartment: R2 = 0.086**",size=3)+
  annotate("text",x=0.18,y=-0.14,label="Degradation: R2 = 0.881***",size=3)+
  #annotate("text",x=0.15,y=-0.16,label="Compartment × Degradation stage: R2 = 0.104*",size=3)+
  theme(strip.text = element_text(size =12,face="bold"),
        legend.title = element_text(colour="black", size=10, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=10,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"))+
  scale_fill_manual(values =  c("red","blue"))+
  scale_color_manual(values =  c("red","blue"))
F_PCOA_plant

#######################################################################################

rs<-read.csv("root_soil.csv",header=T,row.names = 1) 
rs<-rs[,colSums(rs)>0]
gro<-read.csv("amfgroup.csv",header=T,row.names = 1) 
gro<-gro[gro$Compartment%in%c("Root","Soil"),]

gro_root<-gro[gro$Compartment%in%c("Root"),]
gro_soil<-gro[gro$Compartment%in%c("Soil"),]

root_amf<-rs[gro$Compartment%in%c("Root"),]
root_amf<-root_amf[,colSums(root_amf)>0]

soil_amf<-rs[gro$Compartment%in%c("Soil"),]
soil_amf<-soil_amf[,colSums(soil_amf)>0]

plant<-read.csv("plant.csv", header=TRUE, row.names=1)

################################################################################## soil
plant<-read.csv("plant.csv", header=TRUE, row.names=1)
otu_dist <- vegdist(decostand(soil_amf,"hellinger"),method = 'bray')
a_otu_dist_matrix<-as.matrix(otu_dist)
ko_dist <-  vegdist(decostand(plant,"hellinger"),method = 'bray')
a_express_dis_matrix<-as.matrix(ko_dist)

mant <- mantel(a_otu_dist_matrix,a_express_dis_matrix,permutations = 999)
mant
mant_r <- round(mant$statistic,3)
mant_r 
mant_p <- mant$signif
mant_p 
mds.f <- as.data.frame(pcoa(otu_dist)$vectors)
mds.e <- as.data.frame(pcoa(ko_dist)$vectors)

pro <- procrustes(mds.f,mds.e, symmetric = TRUE)
pro 
pro_test <- protest(mds.f,mds.e, permutations = 999)
pro_test 
eigen <- sqrt(pro$svd$d)
percent_var <- signif(eigen/sum(eigen), 4)*100
beta_pro <- data.frame(pro$X)
trans_pro <- data.frame(pro$Yrot)
beta_pro$UserName <- rownames(beta_pro)
beta_pro$type <- "OTU"
trans_pro$UserName <- rownames(trans_pro)
trans_pro$type <- "Plant"
colnames(trans_pro) <- colnames(beta_pro)
pvalue = pro_test$signif
M =round(pro_test$ss,2)
plot <- rbind(beta_pro, trans_pro)
gro_soil$UserName<-row.names(gro_soil)
plot <- left_join(plot,gro_soil,by='UserName')

col11<-c("#00FF7F","#006400","blue")
plot$Degradation<-factor(plot$Degradation,levels=c("Non","Moderately","Severely"),ordered = T)
p1 <- ggplot(plot) +
  geom_point(size = 5, aes(x = Axis.1, y = Axis.2, color =Degradation, shape=type))+labs(title = "Soil AM fungal OTU-Plant") +
  scale_colour_manual(values=col11)+scale_shape_manual(values=c(1,19))+
  theme_classic() +
  geom_line(aes(x= Axis.1, y=Axis.2, group=UserName), col = "darkgrey", alpha = 0.8)+theme_bw() +
  theme(strip.text = element_text(size = 15,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text=element_text(size=10,face="bold"),
        axis.title=element_text(size=15,face="bold"),title=element_text(size=15,face="bold"),legend.position = "right") +
  guides(color=guide_legend(title= "Degradation",byrow = F,title.position = "top",title.hjust = 0.5),alpha=guide_legend(title= "Nlevel",
                                                                                                                   byrow = T,nrow = 3,title.position = "top",title.hjust = 0.5),shape=guide_legend(title="Type",byrow = T,nrow = 2,title.position = "top",title.hjust = 0.5)) +
  annotate("text", x =0.2, y = -0.1, label = paste0("Protest: M=",M,"  p=",pvalue,"\n","Mantel: R=",mant_r,"  p=",mant_p), size = 4) +
  xlab(paste0("PCo1 (",percent_var[1],"%)")) +
  ylab(paste0("PCo2 (",percent_var[2],"%)"))
p1

####
plant<-read.csv("plant.csv", header=TRUE, row.names=1)
otu_dist <- vegdist(decostand(soil_amf[c(1:6),],"hellinger"),method = 'bray')
a_otu_dist_matrix_nd<-as.matrix(otu_dist)
ko_dist <-  vegdist(decostand(plant[c(1:6),],"hellinger"),method = 'bray')
a_express_dis_matrix_nd<-as.matrix(ko_dist)

mant_nd <- mantel(a_otu_dist_matrix_nd,a_express_dis_matrix_nd,permutations = 999)
mant_nd

otu_dist <- vegdist(decostand(soil_amf[c(7:12),],"hellinger"),method = 'bray')
a_otu_dist_matrix_md<-as.matrix(otu_dist)
ko_dist <-  vegdist(decostand(plant[c(7:12),],"hellinger"),method = 'bray')
a_express_dis_matrix_md<-as.matrix(ko_dist)

mant_md <- mantel(a_otu_dist_matrix_md,a_express_dis_matrix_md,permutations = 999)
mant_md 

otu_dist <- vegdist(decostand(soil_amf[c(13:18),],"hellinger"),method = 'bray')
a_otu_dist_matrix_sd<-as.matrix(otu_dist)
ko_dist <-  vegdist(decostand(plant[c(13:18),],"hellinger"),method = 'bray')
a_express_dis_matrix_sd<-as.matrix(ko_dist)

mant_sd <- mantel(a_otu_dist_matrix_sd,a_express_dis_matrix_sd,permutations = 999)
mant_sd 

##################################################################################  root
plant<-read.csv("plant1.csv", header=TRUE, row.names=1)

otu_dist <- vegdist(decostand(root_amf,"hellinger"),method = 'bray')
a_otu_dist_matrix<-as.matrix(otu_dist)
ko_dist <-  vegdist(decostand(plant,"hellinger"),method = 'bray')
a_express_dis_matrix<-as.matrix(ko_dist)

mant <- mantel(a_otu_dist_matrix,a_express_dis_matrix,permutations = 999)
mant 
mant_r <- round(mant$statistic,3)
mant_r 
mant_p <- mant$signif
mant_p 
mds.f <- as.data.frame(pcoa(otu_dist)$vectors)
mds.e <- as.data.frame(pcoa(ko_dist)$vectors)

pro <- procrustes(mds.f,mds.e, symmetric = TRUE)
pro_test <- protest(mds.f,mds.e, permutations = 999)
pro_test 
eigen <- sqrt(pro$svd$d)
percent_var <- signif(eigen/sum(eigen), 4)*100
beta_pro <- data.frame(pro$X)
trans_pro <- data.frame(pro$Yrot)
beta_pro$UserName <- rownames(beta_pro)
beta_pro$type <- "OTU"
trans_pro$UserName <- rownames(trans_pro)
trans_pro$type <- "Plant"
colnames(trans_pro) <- colnames(beta_pro)
pvalue = pro_test$signif
M =round(pro_test$ss,2)
plot <- rbind(beta_pro, trans_pro)
gro_root$UserName<-row.names(gro_root)
plot <- left_join(plot,gro_root,by='UserName')

col11<-c("#00FF7F","#006400","blue")
plot$Degradation<-factor(plot$Degradation,levels=c("Non","Moderately","Severely"),ordered = T)
p2 <- ggplot(plot) +
  geom_point(size = 5, aes(x = Axis.1, y = Axis.2, color =Degradation, shape=type))+labs(title = "Root AM fungal OTU-Plant") +
  scale_colour_manual(values=col11)+scale_shape_manual(values=c(1,19))+
  theme_classic() +
  geom_line(aes(x= Axis.1, y=Axis.2, group=UserName), col = "darkgrey", alpha = 0.8)+theme_bw() +
  theme(strip.text = element_text(size = 15,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=10, face="bold"),
        axis.text=element_text(size=10,face="bold"),
        axis.title=element_text(size=15,face="bold"),title=element_text(size=15,face="bold"),legend.position = "right") +
  guides(color=guide_legend(title= "Degradation",byrow = F,title.position = "top",title.hjust = 0.5),alpha=guide_legend(title= "Nlevel",
                                                                                                                        byrow = T,nrow = 3,title.position = "top",title.hjust = 0.5),shape=guide_legend(title="Type",byrow = T,nrow = 2,title.position = "top",title.hjust = 0.5)) +
  annotate("text", x = -0.1, y = -0.2, label = paste0("Protest: M=",M,"  p=",pvalue,"\n","Mantel: R=",mant_r,"  p=",mant_p), size = 4) +
  xlab(paste0("PCo1 (",percent_var[1],"%)")) +
  ylab(paste0("PCo2 (",percent_var[2],"%)"))  +theme(legend.position="none")
p2

(p2|p1)+plot_annotation(tag_levels = "a")&
  theme(plot.tag = element_text(size=20,face="bold"))

##
plant<-read.csv("plant1.csv", header=TRUE, row.names=1)
otu_dist <- vegdist(decostand(root_amf[c(1:6),],"hellinger"),method = 'bray')
a_otu_dist_matrix_nd<-as.matrix(otu_dist)
ko_dist <-  vegdist(decostand(plant[c(1:6),],"hellinger"),method = 'bray')
a_express_dis_matrix_nd<-as.matrix(ko_dist)

mant_nd_root <- mantel(a_otu_dist_matrix_nd,a_express_dis_matrix_nd,permutations = 999)
mant_nd_root

otu_dist <- vegdist(decostand(root_amf[c(7:12),],"hellinger"),method = 'bray')
a_otu_dist_matrix_md<-as.matrix(otu_dist)
ko_dist <-  vegdist(decostand(plant[c(7:12),],"hellinger"),method = 'bray')
a_express_dis_matrix_md<-as.matrix(ko_dist)

mant_md_root <- mantel(a_otu_dist_matrix_md,a_express_dis_matrix_md,permutations = 999)
mant_md_root 

otu_dist <- vegdist(decostand(root_amf[c(13:18),],"hellinger"),method = 'bray')
a_otu_dist_matrix_sd<-as.matrix(otu_dist)
ko_dist <-  vegdist(decostand(plant[c(13:18),],"hellinger"),method = 'bray')
a_express_dis_matrix_sd<-as.matrix(ko_dist)

mant_sd_root <- mantel(a_otu_dist_matrix_sd,a_express_dis_matrix_sd,permutations = 999)
mant_sd_root

