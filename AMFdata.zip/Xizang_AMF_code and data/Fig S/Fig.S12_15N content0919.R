rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")
library(lme4)
library(lmerTest)
library(modelr)          
library(broom)
library(broom.mixed)          
library(gt)
library(tidyverse)
library(nlme) 
library(Matrix)
library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(patchwork)
library(vegan)
library(scales)
library(ggThemeAssist) 
library(plyr)
library(picante)
library(ggpubr)
library(ggtext)
library(MuMIn)
library(gghalves)

growth<-read.csv("growth.csv",header = T)
n_m<-growth[growth$Degradation%in%c("Non","Moderately"),]
n_s<-growth[growth$Degradation%in%c("Non","Severely"),]
m_s<-growth[growth$Degradation%in%c("Moderately","Severely"),]


fit4.c<- lmer(Plant.15N.content~Degradation_level + (1|Species), data =n_m)
summary(fit4.c)
fit5.c<- lmer(Plant.15N.content~Degradation_level + (1|Species), data =n_s)
summary(fit5.c)
fit6.c<- lmer(Plant.15N.content~Degradation_level + (1|Species), data =m_s)
summary(fit6.c)

shapiro.test(growth$Plant.15N.content)
bartlett.test(growth$Plant.15N.content~Degradation,data = growth)
Plant.15N<-kruskal.test(Plant.15N.content~Degradation,data =growth)
Plant.15N
Plant.15N.k<- kruskal(growth$Plant.15N.content, growth$Degradation, p.adj = 'BH')
Plant.15N.k

p.Plant.15N.content_3<-ggplot(data = growth,
                              aes(x=Degradation, y=Plant.15N.content, fill=Degradation)) +
  geom_half_violin(side = "r", color=NA, alpha=0.4) +
  geom_half_boxplot(side = "r", errorbar.draw = FALSE, width=0.1, linewidth=0.5) +
  geom_half_point_panel(side = "l", shape=21, size=3, color="white")+
  theme_bw()+
  xlab(" ")+
  ylab("Plant<sup>  15</sup>N content (mg)")+
  scale_fill_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_markdown(size=12,face="bold"))+
  geom_segment(aes(x=1, y=0.0155, xend=2, yend=0.0155), color="black") +
  geom_segment(aes(x=2, y=0.016, xend=3, yend=0.016), color="black")+
  geom_segment(aes(x=1, y=0.018, xend=3, yend=0.018), color="black")+
  annotate("text",x=1.5,y=0.0165,label="0.244",size=4,color="black")+
  annotate("text",x=2,y=0.019,label="0.462",size=4,color="black")+
  annotate("text",x=2.5,y=0.017,label="0.796",size=4,color="black")+
  annotate("text",x=2,y=0.022,label=expression(~chi^2==3.555~~P==0.169),size=4,color="red")
p.Plant.15N.content_3















