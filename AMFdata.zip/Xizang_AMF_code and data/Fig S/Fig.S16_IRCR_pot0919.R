---
title: "Untitled"
author: "dq"
date: "2024-10-08"
output: html_document
---

```{r}
rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")
library(lme4)
library(lmerTest)
library(modelr)          
library(broom)
library(broom.mixed)          
library(gt)
library(tidyverse)
library(nlme) 
library(Matrix)
library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(patchwork)
library(vegan)
library(scales)
library(ggThemeAssist) 
library(plyr)
library(picante)
library(ggpubr)
library(ggtext)
library(MuMIn)
library(gghalves)

growth<-read.csv("growth.csv",header = T)
n_m<-growth[growth$Degradation%in%c("Non","Moderately"),]
n_s<-growth[growth$Degradation%in%c("Non","Severely"),]
m_s<-growth[growth$Degradation%in%c("Moderately","Severely"),]



fit7<- lmer(IRCR~Degradation_level + (1|Species), data =n_m)
summary(fit7)
fit8<- lmer(IRCR~Degradation_level + (1|Species), data =n_s)
summary(fit8)
fit9<- lmer(IRCR~Degradation_level + (1|Species), data =m_s)
summary(fit9)

shapiro.test(growth$IRCR)
bartlett.test(growth$IRCR~Degradation,data = growth)
IRCR<-kruskal.test(IRCR~Degradation,data = growth)
IRCR
IRCR.k<- kruskal(growth$IRCR, growth$Degradation, p.adj = 'BH')
IRCR.k

growth$Degradation<-factor(growth$Degradation,levels = c("Non","Moderately","Severely"))
p.IRCR_pot<-ggplot(data =growth,aes(x=Degradation, y=IRCR, color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .2, size=.7)+
  geom_boxplot(width=0.6)+
  xlab("")+ylab("Intra-radical colonization rate\n (IRCR, %)")+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  annotate("text",x=2,y=50,label=expression(~chi^2==7.347~~P==0.025),size=4,color="red")+
  annotate("text",x=1,y=30,label="b",size=5,color="black")+
  annotate("text",x=2,y=45,label="ab",size=5,color="black")+
  annotate("text",x=3,y=50,label="a",size=5,color="black")+
  theme(axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
p.IRCR_pot
```

