rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")
library(lme4)
library(lmerTest)
library(modelr)          
library(broom)
library(broom.mixed)          
library(gt)
library(tidyverse)
library(nlme) 
library(Matrix)
library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(patchwork)
library(vegan)
library(scales)
library(ggThemeAssist) 
library(plyr)
library(picante)
library(ggpubr)
library(ggtext)
library(MuMIn)
library(gghalves)

IRCR<-read.csv("non_AM.csv",header = T)

shapiro.test(IRCR$IRCR)
bartlett.test(IRCR~Degradation,data = IRCR)
IRCR_kw<-kruskal.test(IRCR~Degradation,data = IRCR)
IRCR_kw
IRCR_kw<- kruskal(IRCR$IRCR, IRCR$Degradation, p.adj = 'BH')
IRCR_kw

IRCR$Degradation<-factor(IRCR$Degradation,levels = c("Non","Moderately","Severely"))

ggplot(data=IRCR, aes(x=Degradation, y=IRCR,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .2, size=.7)+
  geom_boxplot(width=0.6)+
  xlab("")+ylab("          The Intra-radical colonization rate of 
     non-mycorrhizal treatments")+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(0,10))+
  theme_bw()+
  annotate("text",x=2.05,y=8,label=expression(~chi^2==2.803~~P==0.246),size=6,color="red")+
  theme(axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=17,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+theme(legend.position="none")
 






