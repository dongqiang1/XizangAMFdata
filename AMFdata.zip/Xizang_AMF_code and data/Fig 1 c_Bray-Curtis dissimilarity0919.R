
rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(patchwork)
library(vegan)
library(scales)
library(ggtern)
library(labdsv) 
library(ggThemeAssist) 
library(plyr)
library(picante)
library(ggpubr)
library(ggtext)

#################################################Bray–Curtis dissimilarity between root and soil arbuscular mycorrhizal fungal community
rs<-read.csv("root_soil.csv",header=T,row.names = 1) 
rs<-rs[,colSums(rs)>0]
gro<-read.csv("amfgroup.csv",header=T,row.names = 1) 
gro<-gro[gro$Compartment%in%c("Root","Soil"),]
compartment<-gro$Compartment
degradation<-gro$Degradation
ado<-adonis(rs~compartment*degradation,permutations=999,distance="bray")
ado$aov.tab

l_com<-rs[gro$Degradation=="Non",]
l_gro<-gro[gro$Degradation=="Non",]
l_ado<-adonis(l_com~l_gro$Compartment,permutations=999,distance="bray") 
l_ado$aov.tab 

m_com<-rs[gro$Degradation=="Moderately",]
m_gro<-gro[gro$Degradation=="Moderately",]
m_ado<-adonis(m_com~m_gro$Compartment,permutations=999,distance="bray") 
m_ado$aov.tab   

s_com<-rs[gro$Degradation=="Severely",]
s_gro<-gro[gro$Degradation=="Severely",]
s_ado<-adonis(s_com~s_gro$Compartment,permutations=999,distance="bray") 
s_ado$aov.tab  


l_dis<-decostand(l_com,"hellinger")
l_dis<-vegdist(l_dis,method="bray")
l_dis<-as.matrix(l_dis) 
l_dis_rs<-l_dis[1:6,7:12]
l_dis_rs1<-melt(l_dis_rs)
l_dis_rs2<-data.frame(l_dis_rs1,rep("Non",nrow(l_dis_rs1)))
names(l_dis_rs2)[4]<-c("Degradation")
m_dis<-decostand(m_com,"hellinger")
m_dis<-vegdist(m_dis,method="bray")
m_dis<-as.matrix(m_dis) 
m_dis_rs<-m_dis[1:6,7:12]
m_dis_rs1<-melt(m_dis_rs)
m_dis_rs2<-data.frame(m_dis_rs1,rep("Moderately",nrow(m_dis_rs1)))
names(m_dis_rs2)[4]<-c("Degradation")
s_dis<-decostand(s_com,"hellinger")
s_dis<-vegdist(s_dis,method="bray")
s_dis<-as.matrix(s_dis) 
s_dis_rs<-s_dis[1:6,7:12]
s_dis_rs1<-melt(s_dis_rs)
s_dis_rs2<-data.frame(s_dis_rs1,rep("Severely",nrow(s_dis_rs1)))
names(s_dis_rs2)[4]<-c("Degradation")

all_dis_rs<-rbind(l_dis_rs2,m_dis_rs2,s_dis_rs2)
write.csv(all_dis_rs,"all_dis_rs.csv")
shapiro.test(all_dis_rs$value)
bartlett.test(all_dis_rs$value~Degradation,data =all_dis_rs)
dis_kw<-kruskal.test(all_dis_rs$value~Degradation,data =all_dis_rs)
dis_kw
kw <- kruskal(all_dis_rs$value, all_dis_rs$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('c','b','a')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")

all_dis_rs$Degradation<-factor(all_dis_rs$Degradation,levels = c("Non","Moderately","Severely"))
list = list(c("Non","Moderately"),c("Moderately","Severely"),c("Non","Severely")) 
F_dissimilarity<-ggplot(all_dis_rs,aes(x=Degradation,y=value,color=Degradation))+ 
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  geom_jitter(width=0.15)+ 
  xlab(" ")+
  ylab("Bray–Curtis dissimilarity of AM fungal<br>community between root and soil") +
  scale_y_continuous(limits = c(0,0.6))+
  theme_bw()+
  annotate("text",x=1,y=0.45,label="c",size=5,color="black")+
  annotate("text",x=2,y=0.5,label="b",size=5,color="black")+
  annotate("text",x=3,y=0.53,label="a",size=5,color="black")+
  annotate("text",x=2.05,y=0.6,label=expression(~chi^2==35.858~~P==1.63e-08),size=6,color="red",face="bold")+
  theme(strip.text = element_text(size = 15,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=15, face="bold"),
        legend.text = element_text(colour="black", size=15, face="bold"),
        axis.text=element_text(size=10,face="bold"),
        axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=7,face="bold",color="black"),
        axis.title=element_text(size=14,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9),
        axis.title.y = element_markdown(size=12,face="bold"))+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")
#+
# stat_compare_means(comparisons = list,size=4)
F_dissimilarity

shapiro.test(all_dis_rs$value)
bartlett.test(value~Degradation,data = all_dis_rs)
dis_kw<-kruskal.test(value~Degradation,data = all_dis_rs)
dis_kw
kw <- kruskal(all_dis_rs$value, all_dis_rs$Degradation, p.adj = 'BH')
kw

######################################################################  去除 ND_Root_5 ND_Soil_3
all_dis_rs<-all_dis_rs%>%filter(Var2 != "ND_Root_5")
all_dis_rs<-all_dis_rs%>%filter(Var1 != "ND_Soil_3")
shapiro.test(all_dis_rs$value)
bartlett.test(all_dis_rs$value~Degradation,data =all_dis_rs)
dis_kw<-kruskal.test(all_dis_rs$value~Degradation,data =all_dis_rs)
dis_kw
kw <- kruskal(all_dis_rs$value, all_dis_rs$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('c','b','a')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")

all_dis_rs$Degradation<-factor(all_dis_rs$Degradation,levels = c("Non","Moderately","Severely"))
list = list(c("Non","Moderately"),c("Moderately","Severely"),c("Non","Severely")) 
F_dissimilarity2<-ggplot(all_dis_rs,aes(x=Degradation,y=value,color=Degradation))+ 
  stat_boxplot(geom ="errorbar", width = .3, size=.7)+
  geom_boxplot()+
  geom_jitter(width=0.15)+ 
  annotate("text",x=2.05,y=0.5,label=expression(~chi^2==66.044~~P==4.55e-15),size=6,color="red",face="bold")+
  xlab(" ")+
  ylab("Bray–Curtis dissimilarity of AM fungal<br>community between root and soil") +
  theme_bw()+
  theme(strip.text = element_text(size = 15,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=15, face="bold"),
        legend.text = element_text(colour="black", size=15, face="bold"),
        axis.text=element_text(size=10,face="bold"),
        axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=7,face="bold",color="black"),
        axis.title=element_text(size=14,face="bold"),
        axis.title.y = element_markdown(size=12,face="bold"))+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  stat_compare_means(comparisons = list,size=4)
F_dissimilarity2

