
rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")
library(lme4)
library(lmerTest)
library(modelr)          
library(broom)
library(broom.mixed)          
library(gt)
library(tidyverse)
library(nlme) 
library(Matrix)
library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(patchwork)
library(vegan)
library(scales)
library(ggThemeAssist) 
library(plyr)
library(picante)
library(ggpubr)
library(ggtext)
library(MuMIn)
library(gghalves)

growth<-read.csv("growth.csv",header = T)
n_m<-growth[growth$Degradation%in%c("Non","Moderately"),]
n_s<-growth[growth$Degradation%in%c("Non","Severely"),]
m_s<-growth[growth$Degradation%in%c("Moderately","Severely"),]
 
######################################################################  growth$AMF.13C
fit1<- lmer(AMF.13C~Degradation_level + (1|Species), data =n_m)
summary(fit1)
fit2<- lmer(AMF.13C~Degradation_level + (1|Species), data =n_s)
summary(fit2)
fit3<- lmer(AMF.13C~Degradation_level + (1|Species), data =m_s)
summary(fit3)

shapiro.test(growth$AMF.13C)
bartlett.test(growth$AMF.13C~Degradation,data = growth)
AMF.13C<-kruskal.test(AMF.13C~Degradation,data =growth)
AMF.13C
AMF.13C.k<- kruskal(growth$AMF.13C, growth$Degradation, p.adj = 'BH')
AMF.13C.k
list = list(c("Non","Moderately"),c("Moderately","Severely"),c("Non","Severely")) 
growth$Degradation<-factor(growth$Degradation,levels = c("Non","Moderately","Severely"))
p.AMF.13C<-ggplot(data=growth, aes(x=Degradation, y=AMF.13C,color=Degradation))+
  stat_boxplot(geom ="errorbar", width = .3, size=.7,position = position_dodge(0.85))+
  geom_boxplot(position = position_dodge(0.85))+
  geom_jitter(width=0.15)+ 
  theme_bw()+
  guides(fill=F)+
  xlab(" ")+
  ylab("AM fungal<sup>  13</sup>C (ng g <sup>-1 </sup>)")+
  scale_y_continuous(limits = c(0,22))+
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_markdown(size=12,face="bold"))+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  geom_segment(aes(x=1, y=6, xend=2, yend=6), color="black") +
  geom_segment(aes(x=2, y=16, xend=3, yend=16), color="black")+
  geom_segment(aes(x=1, y=18, xend=3, yend=18), color="black")+
  annotate("text",x=1.5,y=7,label="0.019",size=4,color="black")+
  annotate("text",x=2,y=19,label="0.021",size=4,color="black")+
  annotate("text",x=2.5,y=17,label="0.050",size=4,color="black")+
  annotate("text",x=2,y=22,label=expression(~chi^2==9.920~~P==0.007),size=4,color="red")
  
p.AMF.13C

p.AMF.13C_2<-ggplot(data = growth,
                  aes(x=Degradation, y=AMF.13C, fill=Degradation)) +
  geom_half_violin(side = "r", color=NA, alpha=0.4) +
  geom_half_boxplot(side = "r", errorbar.draw = FALSE, width=0.1, linewidth=0.5) +
  geom_half_point_panel(side = "l", shape=21, size=3, color="white")+
  theme_bw()+
  xlab(" ")+
  ylab("AM fungal<sup>  13</sup>C (ng g <sup>-1 </sup>)")+
  annotate("text",x=2,y=22,label=expression(~chi^2==9.920~~P==0.007),size=4,color="red")+
  scale_fill_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_markdown(size=12,face="bold"))+
  geom_segment(aes(x=1, y=6, xend=2, yend=6), color="black") +
  geom_segment(aes(x=2, y=16, xend=3, yend=16), color="black")+
  geom_segment(aes(x=1, y=18, xend=3, yend=18), color="black")+
  annotate("text",x=1.5,y=7,label="0.019",size=4,color="black")+
  annotate("text",x=2,y=19,label="0.021",size=4,color="black")+
  annotate("text",x=2.5,y=17,label="0.050",size=4,color="black")+
  annotate("text",x=1,y=4,label="b",size=5,color="black")+
  annotate("text",x=2,y=5.5,label="a",size=5,color="black")+
  annotate("text",x=3,y=15.5,label="a",size=5,color="black")
p.AMF.13C_2

######################################################################### Plant.15N
fit4<- lmer(Plant.15N~Degradation_level + (1|Species), data =n_m)
summary(fit4)
fit5<- lmer(Plant.15N~Degradation_level + (1|Species), data =n_s)
summary(fit5)
fit6<- lmer(Plant.15N~Degradation_level + (1|Species), data =m_s)
summary(fit6)

shapiro.test(growth$Plant.15N)
bartlett.test(growth$Plant.15N~Degradation,data = growth)
Plant.15N<-kruskal.test(Plant.15N~Degradation,data =growth)
Plant.15N
Plant.15N.k<- kruskal(growth$Plant.15N, growth$Degradation, p.adj = 'BH')
Plant.15N.k
growth$Degradation<-factor(growth$Degradation,levels = c("Non","Moderately","Severely"))
p.Plant.15N<-ggplot(data=growth, aes(x=Degradation, y=Plant.15N,color=Degradation))+
  stat_boxplot(geom ="errorbar", width = .3, size=.7,position = position_dodge(0.85))+
  geom_boxplot(position = position_dodge(0.85))+
  geom_jitter(width=0.15)+ 
  theme_bw()+
  guides(fill=F)+
  xlab(" ")+
  ylab("Plant<sup>  15</sup>N (mg g<sup>-1 </sup>)")+
  #scale_y_continuous(limits = c(0,0.15))+
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_markdown(size=12,face="bold"))+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  geom_segment(aes(x=1, y=0.1, xend=2, yend=0.1), color="black") +
  geom_segment(aes(x=2, y=0.13, xend=3, yend=0.13), color="black")+
  geom_segment(aes(x=1, y=0.15, xend=3, yend=0.15), color="black")+
  annotate("text",x=1.5,y=0.12,label="0.250",size=4,color="black")+
  annotate("text",x=2,y=0.17,label="0.909",size=4,color="black")+
  annotate("text",x=2.5,y=0.14,label="0.422",size=4,color="black")+
  annotate("text",x=2,y=0.2,label=expression(~chi^2==0.465~~P==0.793),size=4,color="red")

p.Plant.15N

p.Plant.15N_2<-ggplot(data = growth,
                    aes(x=Degradation, y=Plant.15N, fill=Degradation)) +
  geom_half_violin(side = "r", color=NA, alpha=0.4) +
  geom_half_boxplot(side = "r", errorbar.draw = FALSE, width=0.1, linewidth=0.5) +
  geom_half_point_panel(side = "l", shape=21, size=3, color="white")+
  theme_bw()+
  xlab(" ")+
  ylab("Plant<sup>  15</sup>N (mg g<sup>-1 </sup>)")+
  scale_fill_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_markdown(size=12,face="bold"))+
  geom_segment(aes(x=1, y=0.1, xend=2, yend=0.1), color="black") +
  geom_segment(aes(x=2, y=0.13, xend=3, yend=0.13), color="black")+
  geom_segment(aes(x=1, y=0.15, xend=3, yend=0.15), color="black")+
  annotate("text",x=1.5,y=0.11,label="0.250",size=4,color="black")+
  annotate("text",x=2,y=0.16,label="0.909",size=4,color="black")+
  annotate("text",x=2.5,y=0.14,label="0.422",size=4,color="black")+
  annotate("text",x=2,y=0.19,label=expression(~chi^2==0.465~~P==0.793),size=4,color="red")
p.Plant.15N_2

############################################################################# X13C.15N.log
fit10<- lmer(X13C.15N.log~Degradation_level + (1|Species), data =n_m)
summary(fit10)
fit11<- lmer(X13C.15N.log~Degradation_level + (1|Species), data =n_s)
summary(fit11)
fit12<- lmer(X13C.15N.log~Degradation_level + (1|Species), data =m_s)
summary(fit12)

shapiro.test(growth$X13C.15N.log)
bartlett.test(growth$X13C.15N.log~Degradation,data = growth)
aov1<-aov(X13C.15N.log~Degradation,data = growth)
summary(aov1)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
X13C.15N<-kruskal.test(X13C.15N.log~Degradation,data = growth)
X13C.15N
X13C.15N.k<- kruskal(growth$X13C.15N.log, growth$Degradation, p.adj = 'BH')
X13C.15N.k

sig0<-LSD.test(aov1,"Degradation")
sig0<-data.frame(sig0$means)

growth$Degradation<-factor(growth$Degradation,levels = c("Non","Moderately","Severely"))
p.X13C.15N.log<-ggplot(data=growth, aes(x=Degradation, y=X13C.15N.log,color=Degradation))+
  stat_boxplot(geom ="errorbar", width = .3, size=.7,position = position_dodge(0.85))+
  geom_boxplot(position = position_dodge(0.85))+
  geom_jitter(width=0.15)+ 
  theme_bw()+
  xlab(" ")+
  ylab("log(<sup> 13</sup>C:<sup> 15</sup>N)") +
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_markdown(size=12,face="bold"))+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  geom_segment(aes(x=1, y=3.1, xend=2, yend=3.1), color="black") +
  geom_segment(aes(x=2, y=3.3, xend=3, yend=3.3), color="black")+
  geom_segment(aes(x=1, y=4.2, xend=3, yend=4.2), color="black")+
  annotate("text",x=1.5,y=3.3,label="0.034",size=4,color="black")+
  annotate("text",x=2,y=4.4,label="0.005",size=4,color="black")+
  annotate("text",x=2.5,y=3.5,label="0.111",size=4,color="black")+
  annotate("text",x=2,y=4.8,label="F=5.714 P=0.010",size=4,color="red")

p.X13C.15N.log

p.X13C.15N.log_2<-ggplot(data =growth,
                     aes(x=Degradation, y=X13C.15N.log, fill=Degradation)) +
  geom_half_violin(side = "r", color=NA, alpha=0.4) +
  geom_half_boxplot(side = "r", errorbar.draw = FALSE, width=0.1, linewidth=0.5) +
  geom_half_point_panel(side = "l", shape=21, size=3, color="white")+
  theme_bw()+
  xlab(" ")+
  ylab("Log(<sup> 13</sup>C:<sup> 15</sup>N)") +
  scale_fill_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_markdown(size=12,face="bold"))+
  geom_segment(aes(x=1, y=3.1, xend=2, yend=3.1), color="black") +
  geom_segment(aes(x=2, y=3.4, xend=3, yend=3.4), color="black")+
  geom_segment(aes(x=1, y=4.2, xend=3, yend=4.2), color="black")+
  annotate("text",x=1.5,y=3.3,label="0.034",size=4,color="black")+
  annotate("text",x=2,y=4.4,label="0.005",size=4,color="black")+
  annotate("text",x=2.5,y=3.6,label="0.111",size=4,color="black")+
  annotate("text",x=2,y=4.8,label="F=5.714 P=0.010",size=4,color="red")
p.X13C.15N.log_2

############################################################################# X13C.15N
fit7<- lmer(X13C.15N~Degradation_level + (1|Species), data =n_m)
summary(fit7)
fit8<- lmer(X13C.15N~Degradation_level + (1|Species), data =n_s)
summary(fit8)
fit9<- lmer(X13C.15N~Degradation_level + (1|Species), data =m_s)
summary(fit9)

shapiro.test(growth$X13C.15N)
bartlett.test(growth$X13C.15N~Degradation,data = growth)
X13C.15N<-kruskal.test(X13C.15N~Degradation,data = growth)
X13C.15N
X13C.15N.k<- kruskal(growth$X13C.15N, growth$Degradation, p.adj = 'BH')
X13C.15N.k

p.X13C.15N_2<-ggplot(data =growth,
                   aes(x=Degradation, y=X13C.15N, fill=Degradation)) +
  geom_half_violin(side = "r", color=NA, alpha=0.4) +
  geom_half_boxplot(side = "r", errorbar.draw = FALSE, width=0.1, linewidth=0.5) +
  geom_half_point_panel(side = "l", shape=21, size=3, color="white")+
  theme_bw()+
  xlab(" ")+
  ylab("<sup> 13</sup>C :<sup> 15</sup>N") +
  scale_fill_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_markdown(size=12,face="bold"))+
  geom_segment(aes(x=1, y=950, xend=2, yend=950), color="black") +
  geom_segment(aes(x=2, y=1900, xend=3, yend=1900), color="black")+
  geom_segment(aes(x=1, y=2100, xend=3, yend=2100), color="black")+
  annotate("text",x=1.5,y=1050,label="0.074",size=4,color="black")+
  annotate("text",x=2,y=2200,label="0.028",size=4,color="black")+
  annotate("text",x=2.5,y=2000,label="0.096",size=4,color="black")+
  annotate("text",x=2,y=2400,label=expression(~chi^2==6.755~~P==0.034),size=4,color="red")+
  annotate("text",x=1,y=500,label="b",size=5,color="black")+
  annotate("text",x=2,y=840,label="ab",size=5,color="black")+
  annotate("text",x=3,y=1800,label="a",size=5,color="black")
p.X13C.15N_2

pempty <- ggplot() + 
  theme_void()

(pempty|p.AMF.13C_2)/(p.Plant.15N_2|p.X13C.15N_2)+plot_annotation(tag_levels = "a")&
  theme(plot.tag = element_text(size=20,face="bold"))

###############################################################################
fit4.c<- lmer(Plant.15N.content~Degradation_level + (1|Species), data =n_m)
summary(fit4.c)
fit5.c<- lmer(Plant.15N.content~Degradation_level + (1|Species), data =n_s)
summary(fit5.c)
fit6.c<- lmer(Plant.15N.content~Degradation_level + (1|Species), data =m_s)
summary(fit6.c)

shapiro.test(growth$Plant.15N.content)
bartlett.test(growth$Plant.15N.content~Degradation,data = growth)
Plant.15N<-kruskal.test(Plant.15N.content~Degradation,data =growth)
Plant.15N
Plant.15N.k<- kruskal(growth$Plant.15N.content, growth$Degradation, p.adj = 'BH')
Plant.15N.k

p.Plant.15N.content_3<-ggplot(data = growth,
                      aes(x=Degradation, y=Plant.15N.content, fill=Degradation)) +
  geom_half_violin(side = "r", color=NA, alpha=0.4) +
  geom_half_boxplot(side = "r", errorbar.draw = FALSE, width=0.1, linewidth=0.5) +
  geom_half_point_panel(side = "l", shape=21, size=3, color="white")+
  theme_bw()+
  xlab(" ")+
  ylab("Plant<sup>  15</sup>N content (mg)")+
  scale_fill_manual(values =  c("#00FF7F","#006400","blue"))+theme(legend.position="none")+
  theme(strip.text = element_text(size = 15,face="bold"),
        legend.title = element_text(colour="black", size=12, face="bold"),
        legend.text = element_text(colour="black", size=12, face="bold"),
        axis.text.y=element_text(size=10,face="bold",colour="black"),
        axis.text.x=element_text(size=12,face="bold",colour="black"),
        axis.title=element_text(size=15,face="bold",colour="black"),
        axis.title.y = element_markdown(size=12,face="bold"))+
  geom_segment(aes(x=1, y=0.0155, xend=2, yend=0.0155), color="black") +
  geom_segment(aes(x=2, y=0.016, xend=3, yend=0.016), color="black")+
  geom_segment(aes(x=1, y=0.018, xend=3, yend=0.018), color="black")+
  annotate("text",x=1.5,y=0.0165,label="0.244",size=4,color="black")+
  annotate("text",x=2,y=0.019,label="0.462",size=4,color="black")+
  annotate("text",x=2.5,y=0.017,label="0.796",size=4,color="black")+
  annotate("text",x=2,y=0.022,label=expression(~chi^2==3.555~~P==0.169),size=4,color="red")
p.Plant.15N.content_3


##########################################################################

fit7<- lmer(IRCR~Degradation_level + (1|Species), data =n_m)
summary(fit7)
fit8<- lmer(IRCR~Degradation_level + (1|Species), data =n_s)
summary(fit8)
fit9<- lmer(IRCR~Degradation_level + (1|Species), data =m_s)
summary(fit9)

shapiro.test(growth$IRCR)
bartlett.test(growth$IRCR~Degradation,data = growth)
IRCR<-kruskal.test(IRCR~Degradation,data = growth)
IRCR
IRCR.k<- kruskal(growth$IRCR, growth$Degradation, p.adj = 'BH')
IRCR.k

growth$Degradation<-factor(growth$Degradation,levels = c("Non","Moderately","Severely"))
p.IRCR_pot<-ggplot(data =growth,aes(x=Degradation, y=IRCR, color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .2, size=.7)+
  geom_boxplot(width=0.6)+
  xlab("")+ylab("Intra-radical colonization rate\n (IRCR, %)")+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  theme_bw()+
  annotate("text",x=2,y=50,label=expression(~chi^2==7.347~~P==0.025),size=4,color="red")+
  annotate("text",x=1,y=30,label="b",size=5,color="black")+
  annotate("text",x=2,y=45,label="ab",size=5,color="black")+
  annotate("text",x=3,y=50,label="a",size=5,color="black")+
  theme(axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=15,face="bold"))+theme(legend.position="none")
p.IRCR_pot



