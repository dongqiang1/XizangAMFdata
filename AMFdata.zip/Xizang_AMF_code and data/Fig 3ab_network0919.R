
rm(list = ls())
setwd("C:/Users/DQ/Desktop/文章2/degradation_data")
library(GO.db)
library(vegan)
library(permute)        
library(lattice)
library(WGCNA)
#library(multtest)
library(igraph)
library(brainGraph)
library(WGCNA)
library(psych)
library(reshape2)
library(igraph)
library(Hmisc)
library("GUniFrac")
library(sciplot)
library(ggpmisc)
#library(edgeR)
library(indicspecies)
library(BiocManager)
library(patchwork)
library(agricolae)
library(ggplot2)
library(ggraph)
library(colorRamps)

#################################
rs<-read.csv("root_soil.csv",header=T,row.names = 1) 
rs.d<-rs[,colSums(rs)>0]
amfgroup<-read.csv("amfgroup.csv", header=TRUE)
amfid<-read.csv("otuid.csv", header=TRUE)
gro<-read.csv("amfgroup.csv",header=T) 
rsgro<-amfgroup[amfgroup$Compartment%in%c("Root","Soil"),] 

rsnd<-rs.d[rsgro$Degradation%in%c("Non"),]
rsnd1<-rsnd[,colSums(rsnd)>0]
trsnd1<-t(rsnd1)
trsnd1<-data.frame(row.names(trsnd1),trsnd1)
names(trsnd1)[1]<-c("OTU")
nd<-merge(trsnd1,amfid,by="OTU")
nd_order<-nd[order(nd$Genus),]
nd_order1<-nd_order[-(14:15)]
nd_order2<-data.frame(nd_order1)
#write.csv(nd_order2,file = "nd_order3.csv")
nd_order3<-read.csv("nd_order3.csv",header=T,row.names = 1) 

rsmd<-rs.d[rsgro$Degradation%in%c("Moderately"),]
rsmd1<-rsmd[,colSums(rsmd)>0]
trsmd1<-t(rsmd1)
trsmd1<-data.frame(row.names(trsmd1),trsmd1)
names(trsmd1)[1]<-c("OTU")
md<-merge(trsmd1,amfid,by="OTU")
md_order<-md[order(md$Genus),]
md_order1<-md_order[-(14:15)]
md_order2<-data.frame(md_order1)
#write.csv(md_order2,file = "md_order3.csv")
md_order3<-read.csv("md_order3.csv",header=T,row.names = 1) 

rssd<-rs.d[rsgro$Degradation%in%c("Severely"),]
rssd1<-rssd[,colSums(rssd)>0]
trssd1<-t(rssd1)
trssd1<-data.frame(row.names(trssd1),trssd1)
names(trssd1)[1]<-c("OTU")
sd<-merge(trssd1,amfid,by="OTU")
sd_order<-sd[order(sd$Genus),]
sd_order1<-sd_order[-(14:15)]
sd_order2<-data.frame(sd_order1)
#write.csv(sd_order2,file = "sd_order3.csv")
sd_order3<-read.csv("sd_order3.csv",header=T,row.names = 1) 

#par(mfrow=c(3,5), mar=c(1,1,1,1))
par(mfrow=c(1,3))

############### non_degraded 
df1<-nd_order3
df_corr = corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
#cor_l<-as.matrix(df_corr$r)
#cor_l1<-data.frame(cor_l[upper.tri(cor_l)])
#cor_l2<-data.frame(rep("Non",nrow(cor_l1)),cor_l1)
#names(cor_l2)[1:2]<-c("degradation","cor")

df_corr_r = df_corr$r
df_corr_p = df_corr$p
df_corr_r[df_corr_p>0.05|abs(df_corr_r)<0.6] = 0
igraph <- graph_from_adjacency_matrix(df_corr_r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs = V(igraph )[degree(igraph) == 0]
igraph  = delete.vertices(igraph , bad.vs)
igraph 

tax = read.csv('otuid.csv', row.names=1, header=T)
tax = tax[as.character(V(igraph)$name), ] 
V(igraph)$Genus = tax$Genus
node_list = data.frame(
  label = names(V(igraph)),
  genus=V(igraph)$Genus) 
write.graph(igraph, 'networkln.graphml', format = 'graphml')
igraph.weight = E(igraph)$weight
E(igraph)$weight = NA
sum(igraph.weight>0)
sum(igraph.weight<0)
E.color = igraph.weight
E.color = ifelse(E.color>0, "#FF000030",ifelse(E.color<0, "#9999FF","grey"))
E(igraph)$color = as.character(E.color)
set.seed(123)


data2=read.csv("otuid.csv",header=T,row.names=1)
data2<-data2[1]
igraph_col = data2[V(igraph)$name,]
igraph_col2=as.factor(igraph_col)
levels(igraph_col2)

vcol=data2$Genus
vcol[vcol=="Acaulospora"]<-"green"
vcol[vcol=="Ambispora"]<-"#FF3300"
vcol[vcol=="Archaeospora"]<-"#9999FF"
vcol[vcol=="Claroideoglomus"]<-"darkgreen"
vcol[vcol=="Diversispora"]<-"cyan"
vcol[vcol=="Funneliformis"]<-"#CCFFCC"
vcol[vcol=="Glomerales"]<-"grey"
vcol[vcol=="Glomus"]<-"#0000FF"
vcol[vcol=="Paraglomus"]<-"#FF3399"
vcol[vcol=="Rhizophagus"]<-"red"
vcol[vcol=="Scutellospora"]<-"black"
vcol[vcol=="Septoglomus"]<-"navy"

set.seed(123)
color = c("green","#FF3300","#9999FF","darkgreen","cyan","#CCFFCC","grey","#0000FF","#FF3399","red","black","navy")
levels(igraph_col2) = color
V(igraph)$color = as.character(igraph_col2)

f_nd<-plot(igraph,main="a  Non-Degraded\n Positive links: 296\n Negative links: 0",vertex.frame.color=NA,
     edge.lty=1,edge.curved=TRUE,edge.width=0.1,margin=c(0,0,0,0),
     vertex.label=NA,layout=layout_in_circle,vertex.size=5)

num.edges = length(E(igraph)) 
num.edges
num.vertices = length(V(igraph))
num.vertices
connectance = edge_density(igraph,loops=FALSE)
connectance
average.degree = mean(igraph::degree(igraph))
average.degree
average.path.length = average.path.length(igraph)
average.path.length
diameter = diameter(igraph, directed = FALSE, unconnected = TRUE, weights = NULL)
diameter
edge.connectivity = edge_connectivity(igraph)
edge.connectivity
clustering.coefficient = transitivity(igraph)
clustering.coefficient
no.clusters = no.clusters(igraph)
no.clusters
centralization.betweenness = centralization.betweenness(igraph)$centralization
centralization.betweenness
centralization.degree = centralization.degree(igraph)$centralization
centralization.degree

fc = cluster_fast_greedy(igraph,weights =NULL)
modularity = modularity(igraph,membership(fc))
modularity
positive<-sum(igraph.weight>0)
negative<-sum(igraph.weight<0)
prold<-cbind(modularity,num.edges,num.vertices,connectance,average.degree,average.path.length,
             diameter,edge.connectivity,clustering.coefficient,centralization.betweenness,centralization.degree,positive,negative)

###############   Moderately 

df1<-md_order3
df_corr = corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
cor_m<-as.matrix(df_corr$r)
cor_m1<-data.frame(cor_m[upper.tri(cor_m)])
cor_m2<-data.frame(rep("Moderately",nrow(cor_m1)),cor_m1)
names(cor_m2)[1:2]<-c("degradation","cor")

df_corr_r = df_corr$r
df_corr_p = df_corr$p
df_corr_r[df_corr_p>0.05|abs(df_corr_r)<0.6] = 0
igraph <- graph_from_adjacency_matrix(df_corr_r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs = V(igraph )[degree(igraph) == 0]
igraph  = delete.vertices(igraph , bad.vs)
igraph 

tax = read.csv('otuid.csv', row.names=1, header=T)
tax = tax[as.character(V(igraph)$name), ] 
V(igraph)$Genus = tax$Genus
node_list = data.frame(
  label = names(V(igraph)),
  genus=V(igraph)$Genus) 
write.graph(igraph, 'networkm.graphml', format = 'graphml')
igraph.weight = E(igraph)$weight
E(igraph)$weight = NA
sum(igraph.weight>0)
sum(igraph.weight<0)
E.color = igraph.weight

color_red <- rgb(255, 0, 0,alpha=20, maxColorValue = 255)
print(color_red)

E.color = ifelse(E.color>0, "#FF000030",ifelse(E.color<0, "blue","grey"))
E(igraph)$color = as.character(E.color)

data2=read.csv("otuid.csv",header=T,row.names=1)
data2<-data2[1]
igraph_col = data2[V(igraph)$name,]
igraph_col2=as.factor(igraph_col)
levels(igraph_col2)

vcol=data2$Genus
vcol[vcol=="Acaulospora"]<-"green"
vcol[vcol=="Ambispora"]<-"#FF3300"
vcol[vcol=="Claroideoglomus"]<-"darkgreen"
vcol[vcol=="Diversispora"]<-"cyan"
vcol[vcol=="Funneliformis"]<-"#CCFFCC"
vcol[vcol=="Glomerales"]<-"grey"
vcol[vcol=="Glomus"]<-"#0000FF"
vcol[vcol=="Rhizophagus"]<-"red"
vcol[vcol=="Scutellospora"]<-"black"

set.seed(123)
color = c("green","#FF3300","darkgreen","cyan","#CCFFCC","grey","#0000FF","red","black")
levels(igraph_col2) = color
V(igraph)$color = as.character(igraph_col2)

f_md<-plot(igraph,main="b  Moderately Degraded\n Positive links: 493\n Negative links: 18",vertex.frame.color=NA,
     edge.lty=1,edge.curved=TRUE,edge.width=0.1,margin=c(0,0,0,0),
     vertex.label=NA,layout=layout_in_circle,vertex.size=5)

num.edges = length(E(igraph)) 
num.edges
num.vertices = length(V(igraph))
num.vertices
connectance = edge_density(igraph,loops=FALSE)
connectance
average.degree = mean(igraph::degree(igraph))
average.degree
average.path.length = average.path.length(igraph)
average.path.length
diameter = diameter(igraph, directed = FALSE, unconnected = TRUE, weights = NULL)
diameter
edge.connectivity = edge_connectivity(igraph)
edge.connectivity
clustering.coefficient = transitivity(igraph)
clustering.coefficient
no.clusters = no.clusters(igraph)
no.clusters
centralization.betweenness = centralization.betweenness(igraph)$centralization
centralization.betweenness
centralization.degree = centralization.degree(igraph)$centralization
centralization.degree

fc = cluster_fast_greedy(igraph,weights =NULL)
modularity = modularity(igraph,membership(fc))
modularity
positive<-sum(igraph.weight>0)
negative<-sum(igraph.weight<0)
promd<-cbind(modularity,num.edges,num.vertices,connectance,average.degree,average.path.length,
             diameter,edge.connectivity,clustering.coefficient,centralization.betweenness,centralization.degree,positive,negative)

################  Severely
df1<-sd_order3
df_corr = corr.test(t(df1), use="pairwise",method="spearman",adjust="fdr", alpha=.05, ci=FALSE)
cor_s<-as.matrix(df_corr$r)
cor_s1<-data.frame(cor_s[upper.tri(cor_s)])
cor_s2<-data.frame(rep("Severely",nrow(cor_s1)),cor_s1)
names(cor_s2)[1:2]<-c("degradation","cor")

df_corr_r = df_corr$r
df_corr_p = df_corr$p
df_corr_r[df_corr_p>0.05|abs(df_corr_r)<0.6] = 0
igraph <- graph_from_adjacency_matrix(df_corr_r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs = V(igraph )[degree(igraph ) == 0]
igraph  = delete.vertices(igraph , bad.vs)
igraph 

tax = read.csv('otuid.csv', row.names=1, header=T)
tax = tax[as.character(V(igraph)$name), ] 
V(igraph)$Genus = tax$Genus
node_list = data.frame(
  label = names(V(igraph)),
  genus=V(igraph)$Genus) 
write.graph(igraph, 'networks.graphml', format = 'graphml')
igraph.weight = E(igraph)$weight
E(igraph)$weight = NA
sum(igraph.weight>0)
sum(igraph.weight<0)
E.color = igraph.weight
E.color = ifelse(E.color>0, "#FF000030",ifelse(E.color<0, "blue","grey"))
E(igraph)$color = as.character(E.color)

data2=read.csv("otuid.csv",header=T,row.names=1)
data2<-data2[1]
igraph_col = data2[V(igraph)$name,]
igraph_col2=as.factor(igraph_col)
levels(igraph_col2)

vcol=data2$Genus
vcol[vcol=="Acaulospora"]<-"green"
vcol[vcol=="Archaeospora"]<-"#9999FF"
vcol[vcol=="Claroideoglomus"]<-"darkgreen"
vcol[vcol=="Diversispora"]<-"cyan"
vcol[vcol=="Funneliformis"]<-"#CCFFCC"
vcol[vcol=="Glomerales"]<-"grey"
vcol[vcol=="Glomus"]<-"#0000FF"
vcol[vcol=="Paraglomus"]<-"#FF3399"
vcol[vcol=="Rhizophagus"]<-"red"
vcol[vcol=="Scutellospora"]<-"black"
vcol[vcol=="Septoglomus"]<-"navy"

set.seed(123)
color = c("green","#9999FF","darkgreen","cyan","#CCFFCC","grey","#0000FF","#FF3399","red","black","navy")
levels(igraph_col2) = color
V(igraph)$color = as.character(igraph_col2)

f_sd<-plot(igraph,main="c Severely Degraded\n Positive links: 639\n Negative links: 5",vertex.frame.color=NA,
     edge.lty=1,edge.curved=TRUE,edge.width=0.1,margin=c(0,0,0,0),
     vertex.label=NA,layout=layout_in_circle,vertex.size=5)


f_sd_l<-plot(igraph,main="C ",vertex.frame.color=NA,
           edge.lty=1,edge.curved=TRUE,margin=c(0,2,0,2),
           vertex.label=NA,layout=layout_in_circle,vertex.size=5)
f_sd_l

legend("bottom",legend = c("Acaulospora", "Ambispora","Archaeospora","Claroideoglomus","Diversispora",
                            "Funneliformis","Glomerales" ,"Glomus","Paraglomus","Rhizophagus","Scutellospora", "Septoglomus"  ),pch = 21,
       col = c("green","#FF3300","#9999FF","darkgreen","cyan","#CCFFCC","grey","#0000FF","#FF3399","red","black","navy"),
       pt.bg = c("green","#FF3300","#9999FF","darkgreen","cyan","#CCFFCC","grey","#0000FF","#FF3399","red","black","navy"),
       pt.cex=2, cex=1, bty="n", ncol=5,text.width=0.8,adj=0.1,y.intersp =1,x.intersp =1,title.adj = 2)


legend(x=1.3,y=-0.3,legend = c("positive correlations", "negative correlations"),lty = 1,
       col = c("red","blue"),bty="n",text.width=0.2,lwd=4)



num.edges = length(E(igraph)) 
num.edges
num.vertices = length(V(igraph))
num.vertices
connectance = edge_density(igraph,loops=FALSE)
connectance
average.degree = mean(igraph::degree(igraph))
average.degree
average.path.length = average.path.length(igraph)
average.path.length
diameter = diameter(igraph, directed = FALSE, unconnected = TRUE, weights = NULL)
diameter
edge.connectivity = edge_connectivity(igraph)
edge.connectivity
clustering.coefficient = transitivity(igraph)
clustering.coefficient
no.clusters = no.clusters(igraph)
no.clusters
centralization.betweenness = centralization.betweenness(igraph)$centralization
centralization.betweenness
centralization.degree = centralization.degree(igraph)$centralization
centralization.degree

fc = cluster_fast_greedy(igraph,weights =NULL)
modularity = modularity(igraph,membership(fc))
modularity
positive<-sum(igraph.weight>0)
negative<-sum(igraph.weight<0)

prosd<-cbind(modularity,num.edges,num.vertices,connectance,average.degree,average.path.length,
             diameter,edge.connectivity,clustering.coefficient,centralization.betweenness,centralization.degree,positive,negative)

###########################################################################property_network
proall<-rbind(prold,promd,prosd)
proall_network<-data.frame(proall)
proall_network$Degradation<-c('Non_Degraded','Moderately_Degraded','Severely_Degraded')
##write.csv(proall_network,file='proall_network.csv')
proall_network<-read.csv("proall_network.csv", header=TRUE,row.names = 1)

proall_network$Degradation<-factor(proall_network$Degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))

edges<-ggplot(data = proall_network, aes(x=Degradation,y=num.edges)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Number of edges")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(250,700))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
edges

vertices<-ggplot(data = proall_network, aes(x=Degradation,y=num.vertices)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Number of vertices")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(94,105))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
vertices

Connectance<-ggplot(data = proall_network, aes(x=Degradation,y=connectance)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Connectance")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(0.04,0.13))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
Connectance

Average_degree<-ggplot(data = proall_network, aes(x=Degradation,y=average.degree)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Average degree")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(5,13))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
Average_degree

Average_path_length<-ggplot(data = proall_network, aes(x=Degradation,y=average.path.length)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Average path length")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(2,4))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
Average_path_length

diameter<-ggplot(data = proall_network, aes(x=Degradation,y=diameter)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Diameter")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(6,11))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
diameter

Average_clustering_coefficient<-ggplot(data = proall_network, aes(x=Degradation,y=clustering.coefficient)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Average clustering coefficient")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(0.33,0.68))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
Average_clustering_coefficient

centralization.betweenness<-ggplot(data = proall_network, aes(x=Degradation,y=centralization.betweenness)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Centralization betweenness")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(0.05,0.1))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
centralization.betweenness

centralization.degree<-ggplot(data = proall_network, aes(x=Degradation,y=centralization.degree)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Centralization degree")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(0.1,0.2))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
centralization.degree

modularity<-ggplot(data = proall_network, aes(x=Degradation,y=modularity)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+ylab("Modularity")+theme_bw()+
  scale_color_manual(values = c("black"))+
  scale_y_continuous(limits = c(0.3,0.55))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
modularity

pempty <- ggplot() + 
  theme_void()
property_network<-(edges|Connectance|Average_degree|Average_clustering_coefficient)/
                  (centralization.degree|vertices|modularity|Average_path_length)/
                  (diameter|centralization.betweenness|pempty|pempty)

property_network<-(edges|Connectance|Average_degree|Average_clustering_coefficient)/
                  (centralization.degree|vertices|modularity|Average_path_length)/
                  (diameter|centralization.betweenness|diameter|centralization.betweenness)



proall_network_4_data<-proall_network[,c(14,2,4,5,9)]

names(proall_network_4_data)[2:5]<-c("Number of edges","Connectance","Average degree","Clustering coefficient")
proall_network_4_data_new<-melt(proall_network_4_data)
names(proall_network_4_data_new)[2]<-c("property")


p_network_property_4<-ggplot(data =proall_network_4_data_new, aes(x=Degradation,y=value)) + 
  geom_point(size =5, alpha = 0.8)+
  geom_line(aes(x=as.numeric(Degradation))) +
  xlab("")+
  ylab(" ")+
  facet_wrap(~property,nrow = 2)+
  theme_bw()+
  scale_color_manual(values = c("black"))+
  theme(strip.text = element_text(size = 8,face="bold"),
        legend.title = element_text(colour="black", size=8, face="bold"),
        legend.text = element_text(colour="black", size=8, face="bold"),
        axis.text.x=element_text(colour="black",size=8,face="bold"),
        axis.text.y=element_text(colour="black",size=8,face="bold"),
        axis.title=element_text(colour="black",size=13 ,face="bold"))+theme(legend.position="none")
p_network_property_4


property_network_4<- (edges|Connectance|Average_degree|Average_clustering_coefficient)


property_network_4+plot_annotation(tag_levels = "a") &
  theme(plot.tag = element_text(size=20,face="bold"))

property_network_6<- (centralization.degree|vertices|modularity)/(Average_path_length|diameter|centralization.betweenness)
property_network_6+plot_annotation(tag_levels = "a") &
  theme(plot.tag = element_text(size=20,face="bold"))

property_network+plot_annotation(tag_levels = "a") &
  theme(plot.tag = element_text(size=20,face="bold"))



##################################################################################Contribution to Degree

degree_n<-read.csv("degree_ln2.csv",header=T,row.names = 1) 
degree_n$degradation<-rep("Non_Degraded",nrow(degree_n))

degree_m<-read.csv("degree_m2.csv",header=T,row.names = 1) 
degree_m$degradation<-rep("Moderately_Degraded",nrow(degree_m))

degree_s<-read.csv("degree_s2.csv",header=T,row.names = 1) 
degree_s$degradation<-rep("Severely_Degraded",nrow(degree_s))

degree_all<-rbind(degree_n,degree_m,degree_s)
degree_all$degradation<-factor(degree_all$degradation,levels = c("Non_Degraded","Moderately_Degraded","Severely_Degraded"))
col11<-c("green","#FF3300","#9999FF","darkgreen","cyan","#CCFFCC","grey","#0000FF","#FF3399","red","black","navy")
f_degree_contri<-ggplot(degree_all,aes(x=degradation,y=degree,fill=v_genus))+
  geom_bar(stat = "identity",width = 0.6)+
  labs(x=" ",y = "Contribution to Degree")+
  labs(fill="  ")+theme_bw()+
  theme(strip.text = element_text(size = 15,face="bold"),
        panel.spacing = unit(0, "lines"),
        legend.title = element_text(colour="black", size=15, face="bold"),
        legend.text = element_text(colour="black", size=15, face="bold"),
        axis.text=element_text(size=15,face="bold",colour="black"),
        axis.text.x=element_text(angle = 0),
        axis.title=element_text(size=15,face="bold"))+
        scale_fill_manual(values= col11) 
f_degree_contri+ggtitle("b")&
  theme(plot.tag = element_text(size=20,face="bold"))

degreesum<-aggregate(degree_all$degree,by=list(degree_all$v_genus,degree_all$degradation),sum)
degreesum
write.csv(degreesum,file='degreesum.csv')








