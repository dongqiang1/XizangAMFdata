setwd("C:/Users/DQ/Desktop/文章2/degradation_data")

library(agricolae)
library(ape)
library(multcomp)
library(tidyverse)
library(multcompView)
library(ggsci)
library(ggplot2)
library(reshape2)
library(patchwork)
library(vegan)
library(scales)
library(ggtern)
library(labdsv) 
library(ggThemeAssist) 
library(plyr)
library(picante)
library(ggpubr)


# amf biomass allocation
bio_allo<-read.csv("biomass_allocation.csv", header=TRUE)
spore<-bio_allo[,c('sample','Degradation','Spore_density')]
spore$Degradation <- factor(spore$Degradation)
str(spore)
shapiro.test(spore$Spore_density)
bartlett.test(Spore_density~Degradation,data = spore)
aov1<-aov(Spore_density~Degradation,data = spore)
summary(aov1)
sig0<-LSD.test(aov1,"Degradation")
sig0<-data.frame(sig0$means)
sig0<-data.frame(row.names(sig0),sig0)
tukey<-TukeyHSD(aov1)
cld <- multcompLetters4(aov1,tukey)
cld
sig<-c('a','a','b')
sig1<-data.frame(sig0,sig)
names(sig1)[1]<-c("Degradation")
tuk <- glht(aov1, alternative = 'two.sided',linfct=mcp(Degradation='Tukey'))
plot(cld(tuk, level = 0.05, decreasing = F))
bio_allo$Degradation<-factor(bio_allo$Degradation,levels = c("Non","Moderately","Severely"))
pspore<-ggplot(data=bio_allo, aes(x=Degradation, y=Spore_density,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .2, size=.7)+
  geom_boxplot(width=0.6)+
  xlab("")+ylab(expression(Spore~density~(SD)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(1,2.7))+
  theme_bw()+
  annotate("text",x=2.05,y=2.6,label="F = 4.796 P=0.025",size=6,color="red",face="bold")+
  geom_text(data=sig1,aes(x=Degradation,y=Spore_density+std+0.3),label=sig,size=6,color="black")+
  theme(axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=17,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+theme(legend.position="none")
pspore

ERHD<-bio_allo[,c('sample','Degradation','ERHD')]
ERHD$Degradation<-factor(ERHD$Degradation)
str(ERHD)
shapiro.test(ERHD$ERHD)
bartlett.test(ERHD~Degradation,data = ERHD)
EHRD_kw<-kruskal.test(ERHD~Degradation,data = ERHD)
EHRD_kw
kw <- kruskal(ERHD$ERHD, ERHD$Degradation, p.adj = 'BH')
kw
plot(kw)
kw0<-data.frame(kw$means)
kw0<-data.frame(row.names(kw0),kw0)
kwsig<-c('b','c','a')
kwsig<-data.frame(kw0,kwsig)
names(kwsig)[1]<-c("Degradation")
bio_allo$Degradation<-factor(bio_allo$Degradation,levels = c("Non","Moderately","Severely"))
pERHD<-ggplot(data=bio_allo, aes(x=Degradation, y=ERHD,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .2, size=.7)+
  geom_boxplot(width=0.6)+
  xlab("")+ylab(expression(Extra-radical~hyphal~density~(ERHD)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(5,18))+
  theme_bw()+
  annotate("text",x=2.05,y=17.5,label=expression(~chi^2==13.944~~P==0.001),size=6,color="red",face="bold")+
  geom_text(data=kwsig,aes(x=Degradation,y=ERHD.ERHD+std+1.4),label=kwsig$kwsig,size=6,color="black")+
  theme(axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=17,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,    
                                 colour = "red", lineheight =0.9))+theme(legend.position="none")
pERHD



IRCR<-bio_allo[,c('sample','Degradation','IRCR')]
IRCR$Degradation<-factor(IRCR$Degradation)
str(IRCR)
shapiro.test(IRCR$IRCR)
bartlett.test(IRCR~Degradation,data = IRCR)
IRCR_kw<-kruskal.test(IRCR~Degradation,data = IRCR)
IRCR_kw
IRCR_kw<- kruskal(IRCR$IRCR, IRCR$Degradation, p.adj = 'BH')
IRCR_kw
IRCR_kw0<-data.frame(IRCR_kw$means)
IRCR_kw0<-data.frame(row.names(IRCR_kw0),IRCR_kw0)
IRCRsig<-c('b','b','a')
IRCRsig<-data.frame(IRCR_kw0,IRCRsig)
names(IRCRsig)[1]<-c("Degradation")
bio_allo$Degradation<-factor(bio_allo$Degradation,levels = c("Non","Moderately","Severely"))
pIRCR<-ggplot(data=bio_allo, aes(x=Degradation, y=IRCR,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .2, size=.7)+
  geom_boxplot(width=0.6)+
  xlab("")+ylab(expression(Intra-radical~colonization~rate~(IRCR)))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(20,115))+
  theme_bw()+
  annotate("text",x=2.05,y=113,label=expression(~chi^2==11.802~~P==0.003),size=6,color="red",face="bold")+
  geom_text(data=IRCRsig,aes(x=Degradation,y=IRCR.IRCR+std+10),label=IRCRsig$IRCRsig,size=6,color="black")+
  theme(axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=17,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+theme(legend.position="none")
pIRCR




SD_ERHD<-bio_allo[,c('sample','Degradation','SD_ERHD')]
SD_ERHD$Degradation<-factor(SD_ERHD$Degradation)
str(SD_ERHD)
shapiro.test(SD_ERHD$SD_ERHD)
bartlett.test(SD_ERHD~Degradation,data =SD_ERHD)
SD_ERHDaov1<-aov(SD_ERHD~Degradation,data = SD_ERHD)
summary(SD_ERHDaov1)
SD_ERHDsig0<-LSD.test(SD_ERHDaov1,"Degradation")
SD_ERHDsig0<-data.frame(SD_ERHDsig0$means)
SD_ERHDsig0<-data.frame(row.names(SD_ERHDsig0),SD_ERHDsig0)
SD_ERHDtukey<-TukeyHSD(SD_ERHDaov1)
cld <- multcompLetters4(SD_ERHDaov1,SD_ERHDtukey)
cld
SD_ERHDsig<-c('a','a','b')
SD_ERHDsig<-data.frame(SD_ERHDsig0,SD_ERHDsig)
names(SD_ERHDsig)[1]<-c("Degradation")
bio_allo$Degradation<-factor(bio_allo$Degradation,levels = c("Non","Moderately","Severely"))
pS_E<-ggplot(data=bio_allo, aes(x=Degradation, y=SD_ERHD,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .2, size=.7)+
  geom_boxplot(width=0.6)+
  xlab("")+ylab(expression(SD:ERHD))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(0.05,0.5))+
  theme_bw()+
  annotate("text",x=2.05,y=0.47,label=expression(~F==25.020~~P==1.67e-05),size=6,color="red",face="bold")+
  geom_text(data=SD_ERHDsig,aes(x=Degradation,y=SD_ERHD+std+0.05),label=SD_ERHDsig$SD_ERHDsig,size=6,color="black")+
  theme(axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=17,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+theme(legend.position="none")
pS_E


SD_IRCR<-bio_allo[,c('sample','Degradation','SD_IRCR')]
SD_IRCR$Degradation<-factor(SD_IRCR$Degradation)
str(SD_IRCR)
shapiro.test(SD_IRCR$SD_IRCR)
bartlett.test(SD_IRCR~Degradation,data =SD_IRCR)
SD_IRCR_kw<-kruskal.test(SD_IRCR~Degradation,data =SD_IRCR)
SD_IRCR_kw
SD_IRCR_kw<- kruskal(SD_IRCR$SD_IRCR, SD_IRCR$Degradation, p.adj = 'BH')
SD_IRCR_kw
SD_IRCR_kw0<-data.frame(SD_IRCR_kw$means)
SD_IRCR_kw0<-data.frame(row.names(SD_IRCR_kw0),SD_IRCR_kw0)
SD_IRCRsig<-c('a','a','b')
SD_IRCRsig<-data.frame(SD_IRCR_kw0,SD_IRCRsig)
names(SD_IRCRsig)[1]<-c("Degradation")
bio_allo$Degradation<-factor(bio_allo$Degradation,levels = c("Non","Moderately","Severely"))
pS_I<-ggplot(data=bio_allo, aes(x=Degradation, y=SD_IRCR,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .2, size=.7)+
  geom_boxplot(width=0.6)+
  xlab("")+ylab(expression(SD:IRCR))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(0.01,0.07))+
  theme_bw()+
  annotate("text",x=2.05,y=0.065,label=expression(~chi^2==12.316~~P==0.002),size=6,color="red",face="bold")+
  geom_text(data=SD_IRCRsig,aes(x=Degradation,y=SD_IRCR.SD_IRCR+std+0.009),label=SD_IRCRsig$SD_IRCRsig,size=6,color="black")+
  theme(axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=17,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+theme(legend.position="none")
pS_I

ERHD_IRCR<-bio_allo[,c('sample','Degradation','ERHD_IRCR')]
ERHD_IRCR$Degradation<-factor(ERHD_IRCR$Degradation)
str(ERHD_IRCR)
shapiro.test(ERHD_IRCR$ERHD_IRCR)
bartlett.test(ERHD_IRCR~Degradation,data = ERHD_IRCR)
ERHD_IRCR_kw<-kruskal.test(ERHD_IRCR~Degradation,data = ERHD_IRCR)
ERHD_IRCR_kw
ERHD_IRCR_kw<- kruskal(ERHD_IRCR$ERHD_IRCR, ERHD_IRCR$Degradation, p.adj = 'BH')
ERHD_IRCR_kw
ERHD_IRCR_kw0<-data.frame(ERHD_IRCR_kw$means)
ERHD_IRCR_kw0<-data.frame(row.names(ERHD_IRCR_kw0),ERHD_IRCR_kw0)
ERHD_IRCRsig<-c('a','a','a')
ERHD_IRCRsig<-data.frame(ERHD_IRCR_kw0,ERHD_IRCRsig)
names(ERHD_IRCRsig)[1]<-c("Degradation")
bio_allo$Degradation<-factor(bio_allo$Degradation,levels = c("Non","Moderately","Severely"))
pE_I<-ggplot(data=bio_allo, aes(x=Degradation, y=ERHD_IRCR,color=Degradation)) +
  stat_boxplot(geom ="errorbar", width = .2, size=.7)+
  geom_boxplot(width=0.6)+
  xlab("")+ylab(expression(ERHD:IRCR))+
  guides(fill=F)+
  scale_color_manual(values =  c("#00FF7F","#006400","blue"))+
  scale_y_continuous(limits = c(0.1,0.35))+
  theme_bw()+
  annotate("text",x=2.05,y=0.32,label=expression(~chi^2==1.205~~P==0.548),size=6,color="red",face="bold")+
  theme(axis.text.x=element_text(size=15,face="bold",color="black"),
        axis.text.y=element_text(size=10,face="bold",color="black"),
        axis.title=element_text(size=17,face="bold"),
        plot.title=element_text (size = rel(1.2), hjust = 0.5,     
                                 colour = "red", lineheight = .9))+theme(legend.position="none")
pE_I


pempty <- ggplot() + 
  theme_void()
F_bio_all<-(pspore|pERHD|pIRCR)/(pS_E|pS_I|pE_I)/(pempty|pempty|pempty)/(pempty|pempty|pempty)
F_bio_all
F_bio_all+ plot_annotation(tag_levels = "a")&
  theme(plot.tag = element_text(size=20,face="bold"))





